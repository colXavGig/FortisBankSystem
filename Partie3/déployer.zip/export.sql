--------------------------------------------------------
--  Fichier créé - mardi-avril-22-2025   
--------------------------------------------------------
DROP TABLE "C##JAVA_BANK"."AccountTask" cascade constraints;
DROP TABLE "C##JAVA_BANK"."BankAccount" cascade constraints;
DROP TABLE "C##JAVA_BANK"."CheckingAccount" cascade constraints;
DROP TABLE "C##JAVA_BANK"."Client" cascade constraints;
DROP TABLE "C##JAVA_BANK"."CreditAccount" cascade constraints;
DROP TABLE "C##JAVA_BANK"."CurrencyAccount" cascade constraints;
DROP TABLE "C##JAVA_BANK"."Manager" cascade constraints;
DROP TABLE "C##JAVA_BANK"."Notification" cascade constraints;
DROP TABLE "C##JAVA_BANK"."SavingAccount" cascade constraints;
DROP TABLE "C##JAVA_BANK"."Task" cascade constraints;
DROP TABLE "C##JAVA_BANK"."TransactionRecord" cascade constraints;
DROP TABLE "C##JAVA_BANK"."User" cascade constraints;
DROP TABLE "C##JAVA_BANK"."UserTask" cascade constraints;
DROP VIEW "C##JAVA_BANK"."AccountTaskView";
DROP VIEW "C##JAVA_BANK"."ActiveBankAccountView";
DROP VIEW "C##JAVA_BANK"."ActiveUserView";
DROP VIEW "C##JAVA_BANK"."CheckingAccountView";
DROP VIEW "C##JAVA_BANK"."ClientView";
DROP VIEW "C##JAVA_BANK"."CreditAccountView";
DROP VIEW "C##JAVA_BANK"."CurrencyAccountView";
DROP VIEW "C##JAVA_BANK"."ManagerView";
DROP VIEW "C##JAVA_BANK"."RemovedBankAccountView";
DROP VIEW "C##JAVA_BANK"."RemovedUserView";
DROP VIEW "C##JAVA_BANK"."SavingAccountView";
DROP VIEW "C##JAVA_BANK"."UserTaskView";
DROP PROCEDURE "C##JAVA_BANK"."ARCHIVENOTIFICATION";
DROP PROCEDURE "C##JAVA_BANK"."CREATEACCOUNTTASK";
DROP PROCEDURE "C##JAVA_BANK"."CREATECHECKINGACCOUNT";
DROP PROCEDURE "C##JAVA_BANK"."CREATECLIENT";
DROP PROCEDURE "C##JAVA_BANK"."CREATECREDITACCOUNT";
DROP PROCEDURE "C##JAVA_BANK"."CREATECURRENCYACCOUNT";
DROP PROCEDURE "C##JAVA_BANK"."CREATEMANAGER";
DROP PROCEDURE "C##JAVA_BANK"."CREATENOTIFICATION";
DROP PROCEDURE "C##JAVA_BANK"."CREATESAVINGACCOUNT";
DROP PROCEDURE "C##JAVA_BANK"."CREATETRANSACTIONRECORD";
DROP PROCEDURE "C##JAVA_BANK"."CREATEUSERTASK";
DROP PROCEDURE "C##JAVA_BANK"."DELETECHECKINGACCOUNT";
DROP PROCEDURE "C##JAVA_BANK"."DELETECLIENT";
DROP PROCEDURE "C##JAVA_BANK"."DELETECREDITACCOUNT";
DROP PROCEDURE "C##JAVA_BANK"."DELETECURRENCYACCOUNT";
DROP PROCEDURE "C##JAVA_BANK"."DELETEMANAGER";
DROP PROCEDURE "C##JAVA_BANK"."DELETESAVINGACCOUNT";
DROP PROCEDURE "C##JAVA_BANK"."DELETEUSERTASK";
DROP PROCEDURE "C##JAVA_BANK"."SETNOTIFICATIONTOREAD";
DROP PROCEDURE "C##JAVA_BANK"."UPDATEACCOUNTTASK";
DROP PROCEDURE "C##JAVA_BANK"."UPDATECHECKINGACCOUNT";
DROP PROCEDURE "C##JAVA_BANK"."UPDATECLIENT";
DROP PROCEDURE "C##JAVA_BANK"."UPDATECREDITACCOUNT";
DROP PROCEDURE "C##JAVA_BANK"."UPDATECURRENCYACCOUNT";
DROP PROCEDURE "C##JAVA_BANK"."UPDATEMANAGER";
DROP PROCEDURE "C##JAVA_BANK"."UPDATENOTIFICATION";
DROP PROCEDURE "C##JAVA_BANK"."UPDATESAVINGACCOUNT";
DROP PROCEDURE "C##JAVA_BANK"."UPDATEUSERTASK";
DROP FUNCTION "C##JAVA_BANK"."READACCOUNTTASKBYID";
DROP FUNCTION "C##JAVA_BANK"."READALLACCOUNTTASKS";
DROP FUNCTION "C##JAVA_BANK"."READALLCHECKINGACCOUNTS";
DROP FUNCTION "C##JAVA_BANK"."READALLCLIENTS";
DROP FUNCTION "C##JAVA_BANK"."READALLCREDITACCOUNTS";
DROP FUNCTION "C##JAVA_BANK"."READALLCURRENCYACCOUNTS";
DROP FUNCTION "C##JAVA_BANK"."READALLMANAGERS";
DROP FUNCTION "C##JAVA_BANK"."READALLNOTIFICATIONSFORBANKACCOUNT";
DROP FUNCTION "C##JAVA_BANK"."READALLPENDINGACCOUNTTASKS";
DROP FUNCTION "C##JAVA_BANK"."READALLPENDINGUSERTASKS";
DROP FUNCTION "C##JAVA_BANK"."READALLSAVINGACCOUNTS";
DROP FUNCTION "C##JAVA_BANK"."READALLTRANSACTIONRECORDS";
DROP FUNCTION "C##JAVA_BANK"."READALLUNREADNOTIFICATIONSFORCLIENT";
DROP FUNCTION "C##JAVA_BANK"."READALLUSERTASKS";
DROP FUNCTION "C##JAVA_BANK"."READCHECKINGACCOUNTBYID";
DROP FUNCTION "C##JAVA_BANK"."READCLIENTBYID";
DROP FUNCTION "C##JAVA_BANK"."READCREDITACCOUNTBYID";
DROP FUNCTION "C##JAVA_BANK"."READCURRENCYACCOUNTBYID";
DROP FUNCTION "C##JAVA_BANK"."READMANAGERBYID";
DROP FUNCTION "C##JAVA_BANK"."READSAVINGACCOUNTBYID";
DROP FUNCTION "C##JAVA_BANK"."READTRANSACTIONRECORDFOR";
DROP FUNCTION "C##JAVA_BANK"."READUSERBYEMAIL";
DROP FUNCTION "C##JAVA_BANK"."READUSERTASKBYID";
--------------------------------------------------------
--  DDL for Table AccountTask
--------------------------------------------------------

  CREATE TABLE "C##JAVA_BANK"."AccountTask" 
   (	"taskID" NUMBER(*,0), 
	"bank_accountID" NUMBER(*,0)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table BankAccount
--------------------------------------------------------

  CREATE TABLE "C##JAVA_BANK"."BankAccount" 
   (	"ID" NUMBER(*,0), 
	"userID" NUMBER(*,0), 
	"balance" NUMBER(10,2), 
	"creation_date" DATE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table CheckingAccount
--------------------------------------------------------

  CREATE TABLE "C##JAVA_BANK"."CheckingAccount" 
   (	"bank_accountID" NUMBER(*,0), 
	"transaction_fee" NUMBER(10,2)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table Client
--------------------------------------------------------

  CREATE TABLE "C##JAVA_BANK"."Client" 
   (	"userID" NUMBER(*,0)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table CreditAccount
--------------------------------------------------------

  CREATE TABLE "C##JAVA_BANK"."CreditAccount" 
   (	"bank_accountID" NUMBER(*,0), 
	"interest_rate" NUMBER(10,2)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table CurrencyAccount
--------------------------------------------------------

  CREATE TABLE "C##JAVA_BANK"."CurrencyAccount" 
   (	"bank_accountID" NUMBER(*,0), 
	"currency" VARCHAR2(3 BYTE), 
	"exchange_rate" NUMBER(10,4)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table Manager
--------------------------------------------------------

  CREATE TABLE "C##JAVA_BANK"."Manager" 
   (	"userID" NUMBER(*,0), 
	"role" VARCHAR2(50 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table Notification
--------------------------------------------------------

  CREATE TABLE "C##JAVA_BANK"."Notification" 
   (	"ID" NUMBER(*,0), 
	"bank_accountID" NUMBER(*,0), 
	"clientID" NUMBER(*,0), 
	"status" VARCHAR2(50 BYTE), 
	"message" VARCHAR2(250 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table SavingAccount
--------------------------------------------------------

  CREATE TABLE "C##JAVA_BANK"."SavingAccount" 
   (	"bank_accountID" NUMBER(*,0), 
	"interest_rate" NUMBER(5,4)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table Task
--------------------------------------------------------

  CREATE TABLE "C##JAVA_BANK"."Task" 
   (	"ID" NUMBER(*,0), 
	"status" VARCHAR2(50 BYTE), 
	"action_type" VARCHAR2(50 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table TransactionRecord
--------------------------------------------------------

  CREATE TABLE "C##JAVA_BANK"."TransactionRecord" 
   (	"historicID" NUMBER(*,0), 
	"bank_accountID" NUMBER(*,0), 
	"type" VARCHAR2(50 BYTE), 
	"operation" NUMBER(10,2), 
	"date" DATE, 
	"balance" NUMBER(10,2)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table User
--------------------------------------------------------

  CREATE TABLE "C##JAVA_BANK"."User" 
   (	"ID" NUMBER(*,0), 
	"firstname" VARCHAR2(50 BYTE), 
	"lastname" VARCHAR2(50 BYTE), 
	"nip" VARCHAR2(50 BYTE), 
	"address" VARCHAR2(250 BYTE), 
	"telephone" VARCHAR2(50 BYTE), 
	"email" VARCHAR2(100 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table UserTask
--------------------------------------------------------

  CREATE TABLE "C##JAVA_BANK"."UserTask" 
   (	"taskID" NUMBER(*,0), 
	"userID" NUMBER(*,0), 
	"user_type" VARCHAR2(50 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for View AccountTaskView
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "C##JAVA_BANK"."AccountTaskView" ("taskID", "bank_accountID", "status", "action_type") AS 
  SELECT
    at."taskID",
    at."bank_accountID",
    t."status",
    t."action_type"
FROM "AccountTask" at
INNER JOIN "Task" t ON at."taskID" = t."ID"
;
--------------------------------------------------------
--  DDL for View ActiveBankAccountView
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "C##JAVA_BANK"."ActiveBankAccountView" ("ID", "userID", "balance", "creation_date") AS 
  SELECT
    ba."ID",
    ba."userID",
    ba."balance",
    ba."creation_date"
FROM "BankAccount" ba
INNER JOIN "AccountTaskView" at ON ba."ID" = at."bank_accountID"
WHERE ba."ID" NOT IN (SELECT "ID" FROM "RemovedBankAccountView")
  AND at."action_type" = 'creation'
  AND at."status" NOT IN ('pending', 'in progress', 'rejected')
;
--------------------------------------------------------
--  DDL for View ActiveUserView
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "C##JAVA_BANK"."ActiveUserView" ("ID", "firstname", "lastname", "nip", "address", "telephone", "email") AS 
  SELECT u."ID",u."firstname",u."lastname",u."nip",u."address",u."telephone",u."email"
FROM "User" u
INNER JOIN "UserTaskView" ut ON u."ID" = ut."userID"
WHERE u."ID" NOT IN (SELECT "ID" FROM "RemovedUserView")
  AND ut."action_type" = 'creation'
  AND ut."status" <> 'pending'
  AND ut."status" <> 'in_progress'
  AND ut."status" <> 'rejected'
;
--------------------------------------------------------
--  DDL for View CheckingAccountView
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "C##JAVA_BANK"."CheckingAccountView" ("CHECKING_ACCOUNTID", "userID", "balance", "creation_date", "transaction_fee") AS 
  SELECT
    ba."ID" AS checking_accountID,
    ba."userID",
    ba."balance",
    ba."creation_date",
    ca."transaction_fee"
FROM "ActiveBankAccountView" ba
INNER JOIN "CheckingAccount" ca ON ba."ID" = ca."bank_accountID"
;
--------------------------------------------------------
--  DDL for View ClientView
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "C##JAVA_BANK"."ClientView" ("CLIENTID", "firstname", "lastname", "nip", "address", "telephone", "email") AS 
  SELECT c."userID" AS clientID, u."firstname", u."lastname", u."nip", u."address", u."telephone", u."email"
FROM "ActiveUserView" u
INNER JOIN "Client" c ON u."ID" = c."userID"
;
--------------------------------------------------------
--  DDL for View CreditAccountView
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "C##JAVA_BANK"."CreditAccountView" ("CREDIT_ACCOUNTID", "userID", "balance", "creation_date", "interest_rate") AS 
  SELECT
    ba."ID" AS credit_accountID,
    ba."userID",
    ba."balance",
    ba."creation_date",
    ca."interest_rate"
FROM "ActiveBankAccountView" ba
INNER JOIN "CreditAccount" ca ON ba."ID" = ca."bank_accountID"
;
--------------------------------------------------------
--  DDL for View CurrencyAccountView
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "C##JAVA_BANK"."CurrencyAccountView" ("CURRENCY_ACCOUNTID", "userID", "balance", "creation_date", "currency", "exchange_rate") AS 
  SELECT
    ba."ID" AS currency_accountID,
    ba."userID",
    ba."balance",
    ba."creation_date",
    ca."currency",
    ca."exchange_rate"
FROM "ActiveBankAccountView" ba
INNER JOIN "CurrencyAccount" ca ON ba."ID" = ca."bank_accountID"
;
--------------------------------------------------------
--  DDL for View ManagerView
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "C##JAVA_BANK"."ManagerView" ("MANAGERID", "firstname", "lastname", "nip", "address", "telephone", "email", "role") AS 
  SELECT m."userID" AS managerID, u."firstname", u."lastname", u."nip", u."address", u."telephone", u."email", m."role"
FROM "ActiveUserView" u
INNER JOIN "Manager" m ON u."ID" = m."userID"
;
--------------------------------------------------------
--  DDL for View RemovedBankAccountView
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "C##JAVA_BANK"."RemovedBankAccountView" ("ID", "userID", "balance", "creation_date") AS 
  SELECT
    ba."ID",
    ba."userID",
    ba."balance",
    ba."creation_date"
FROM "BankAccount" ba
INNER JOIN "AccountTaskView" at ON ba."ID" = at."bank_accountID"
WHERE at."action_type" = 'deletion'
  AND at."status" NOT IN ('pending', 'in progress', 'rejected')
;
--------------------------------------------------------
--  DDL for View RemovedUserView
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "C##JAVA_BANK"."RemovedUserView" ("ID", "firstname", "lastname", "nip", "address", "telephone", "email") AS 
  SELECT u."ID",u."firstname",u."lastname",u."nip",u."address",u."telephone",u."email"
FROM "User" u
INNER JOIN "UserTaskView" ut ON u."ID" = ut."userID"
WHERE ut."action_type" = 'deletion'
  AND ut."status" <> 'pending'
  AND ut."status" <> 'in_progress'
  AND ut."status" <> 'rejected'
;
--------------------------------------------------------
--  DDL for View SavingAccountView
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "C##JAVA_BANK"."SavingAccountView" ("SAVING_ACCOUNTID", "userID", "balance", "creation_date", "interest_rate") AS 
  SELECT
    ba."ID" AS saving_accountID,
    ba."userID",
    ba."balance",
    ba."creation_date",
    sa."interest_rate"
FROM "ActiveBankAccountView" ba
INNER JOIN "SavingAccount" sa ON ba."ID" = sa."bank_accountID"
;
--------------------------------------------------------
--  DDL for View UserTaskView
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "C##JAVA_BANK"."UserTaskView" ("taskID", "status", "action_type", "userID", "user_type") AS 
  SELECT
    ct."taskID",
    "Task"."status",
    "Task"."action_type",
    ct."userID",
    ct."user_type"
FROM "UserTask" ct
INNER JOIN "Task" ON ct."taskID" = "Task"."ID"
;
REM INSERTING into C##JAVA_BANK."AccountTask"
SET DEFINE OFF;
Insert into C##JAVA_BANK."AccountTask" ("taskID","bank_accountID") values ('11','1');
Insert into C##JAVA_BANK."AccountTask" ("taskID","bank_accountID") values ('12','2');
Insert into C##JAVA_BANK."AccountTask" ("taskID","bank_accountID") values ('13','3');
Insert into C##JAVA_BANK."AccountTask" ("taskID","bank_accountID") values ('14','4');
Insert into C##JAVA_BANK."AccountTask" ("taskID","bank_accountID") values ('15','5');
Insert into C##JAVA_BANK."AccountTask" ("taskID","bank_accountID") values ('16','6');
Insert into C##JAVA_BANK."AccountTask" ("taskID","bank_accountID") values ('17','7');
Insert into C##JAVA_BANK."AccountTask" ("taskID","bank_accountID") values ('18','8');
Insert into C##JAVA_BANK."AccountTask" ("taskID","bank_accountID") values ('19','9');
Insert into C##JAVA_BANK."AccountTask" ("taskID","bank_accountID") values ('20','10');
REM INSERTING into C##JAVA_BANK."BankAccount"
SET DEFINE OFF;
Insert into C##JAVA_BANK."BankAccount" (ID,"userID","balance","creation_date") values ('1','1','1000',to_date('23-01-15','RR-MM-DD'));
Insert into C##JAVA_BANK."BankAccount" (ID,"userID","balance","creation_date") values ('2','2','2500,5',to_date('23-02-20','RR-MM-DD'));
Insert into C##JAVA_BANK."BankAccount" (ID,"userID","balance","creation_date") values ('3','3','500,75',to_date('23-03-10','RR-MM-DD'));
Insert into C##JAVA_BANK."BankAccount" (ID,"userID","balance","creation_date") values ('4','4','12000',to_date('23-04-01','RR-MM-DD'));
Insert into C##JAVA_BANK."BankAccount" (ID,"userID","balance","creation_date") values ('5','5','750,25',to_date('23-05-05','RR-MM-DD'));
Insert into C##JAVA_BANK."BankAccount" (ID,"userID","balance","creation_date") values ('6','1','1000',to_date('23-01-15','RR-MM-DD'));
Insert into C##JAVA_BANK."BankAccount" (ID,"userID","balance","creation_date") values ('7','2','2500,5',to_date('23-02-20','RR-MM-DD'));
Insert into C##JAVA_BANK."BankAccount" (ID,"userID","balance","creation_date") values ('8','3','500,75',to_date('23-03-10','RR-MM-DD'));
Insert into C##JAVA_BANK."BankAccount" (ID,"userID","balance","creation_date") values ('9','4','12000',to_date('23-04-01','RR-MM-DD'));
Insert into C##JAVA_BANK."BankAccount" (ID,"userID","balance","creation_date") values ('10','5','750,25',to_date('23-05-05','RR-MM-DD'));
Insert into C##JAVA_BANK."BankAccount" (ID,"userID","balance","creation_date") values ('11','1','1000',to_date('23-01-15','RR-MM-DD'));
Insert into C##JAVA_BANK."BankAccount" (ID,"userID","balance","creation_date") values ('12','2','2500,5',to_date('23-02-20','RR-MM-DD'));
Insert into C##JAVA_BANK."BankAccount" (ID,"userID","balance","creation_date") values ('13','3','500,75',to_date('23-03-10','RR-MM-DD'));
Insert into C##JAVA_BANK."BankAccount" (ID,"userID","balance","creation_date") values ('14','4','12000',to_date('23-04-01','RR-MM-DD'));
Insert into C##JAVA_BANK."BankAccount" (ID,"userID","balance","creation_date") values ('15','5','750,25',to_date('23-05-05','RR-MM-DD'));
Insert into C##JAVA_BANK."BankAccount" (ID,"userID","balance","creation_date") values ('16','1','1000',to_date('23-01-15','RR-MM-DD'));
Insert into C##JAVA_BANK."BankAccount" (ID,"userID","balance","creation_date") values ('17','2','2500,5',to_date('23-02-20','RR-MM-DD'));
Insert into C##JAVA_BANK."BankAccount" (ID,"userID","balance","creation_date") values ('18','3','500,75',to_date('23-03-10','RR-MM-DD'));
Insert into C##JAVA_BANK."BankAccount" (ID,"userID","balance","creation_date") values ('19','4','12000',to_date('23-04-01','RR-MM-DD'));
Insert into C##JAVA_BANK."BankAccount" (ID,"userID","balance","creation_date") values ('20','5','750,25',to_date('23-05-05','RR-MM-DD'));
REM INSERTING into C##JAVA_BANK."CheckingAccount"
SET DEFINE OFF;
Insert into C##JAVA_BANK."CheckingAccount" ("bank_accountID","transaction_fee") values ('1','1');
Insert into C##JAVA_BANK."CheckingAccount" ("bank_accountID","transaction_fee") values ('2','1,5');
Insert into C##JAVA_BANK."CheckingAccount" ("bank_accountID","transaction_fee") values ('3','0,75');
Insert into C##JAVA_BANK."CheckingAccount" ("bank_accountID","transaction_fee") values ('4','2');
Insert into C##JAVA_BANK."CheckingAccount" ("bank_accountID","transaction_fee") values ('5','1,25');
REM INSERTING into C##JAVA_BANK."Client"
SET DEFINE OFF;
Insert into C##JAVA_BANK."Client" ("userID") values ('1');
Insert into C##JAVA_BANK."Client" ("userID") values ('2');
Insert into C##JAVA_BANK."Client" ("userID") values ('3');
Insert into C##JAVA_BANK."Client" ("userID") values ('4');
Insert into C##JAVA_BANK."Client" ("userID") values ('5');
REM INSERTING into C##JAVA_BANK."CreditAccount"
SET DEFINE OFF;
Insert into C##JAVA_BANK."CreditAccount" ("bank_accountID","interest_rate") values ('16','19,5');
Insert into C##JAVA_BANK."CreditAccount" ("bank_accountID","interest_rate") values ('17','14');
Insert into C##JAVA_BANK."CreditAccount" ("bank_accountID","interest_rate") values ('18','21');
Insert into C##JAVA_BANK."CreditAccount" ("bank_accountID","interest_rate") values ('19','15,5');
Insert into C##JAVA_BANK."CreditAccount" ("bank_accountID","interest_rate") values ('20','18');
REM INSERTING into C##JAVA_BANK."CurrencyAccount"
SET DEFINE OFF;
Insert into C##JAVA_BANK."CurrencyAccount" ("bank_accountID","currency","exchange_rate") values ('11','AUD','1,3');
Insert into C##JAVA_BANK."CurrencyAccount" ("bank_accountID","currency","exchange_rate") values ('12','CAD','1,25');
Insert into C##JAVA_BANK."CurrencyAccount" ("bank_accountID","currency","exchange_rate") values ('13','NZD','1,45');
Insert into C##JAVA_BANK."CurrencyAccount" ("bank_accountID","currency","exchange_rate") values ('14','USD','1');
Insert into C##JAVA_BANK."CurrencyAccount" ("bank_accountID","currency","exchange_rate") values ('15','EUR','0,85');
REM INSERTING into C##JAVA_BANK."Manager"
SET DEFINE OFF;
Insert into C##JAVA_BANK."Manager" ("userID","role") values ('6','HR Manager');
Insert into C##JAVA_BANK."Manager" ("userID","role") values ('7','Marketing Manager');
Insert into C##JAVA_BANK."Manager" ("userID","role") values ('8','Sales Manager');
Insert into C##JAVA_BANK."Manager" ("userID","role") values ('9','Operations Manager');
Insert into C##JAVA_BANK."Manager" ("userID","role") values ('10','Financial Manager');
REM INSERTING into C##JAVA_BANK."Notification"
SET DEFINE OFF;
Insert into C##JAVA_BANK."Notification" (ID,"bank_accountID","clientID","status","message") values ('1','1','1','sent','Your account balance is low.');
Insert into C##JAVA_BANK."Notification" (ID,"bank_accountID","clientID","status","message") values ('2','2','2','read','A large withdrawal was made from your account.');
Insert into C##JAVA_BANK."Notification" (ID,"bank_accountID","clientID","status","message") values ('3','3','3','archived','Your deposit was successful.');
Insert into C##JAVA_BANK."Notification" (ID,"bank_accountID","clientID","status","message") values ('4','4','4','sent','Your credit card payment is due soon.');
Insert into C##JAVA_BANK."Notification" (ID,"bank_accountID","clientID","status","message") values ('5','5','5','read','A new transaction has been recorded on your account.');
Insert into C##JAVA_BANK."Notification" (ID,"bank_accountID","clientID","status","message") values ('6','6','1','archived','Your account has been credited with interest.');
Insert into C##JAVA_BANK."Notification" (ID,"bank_accountID","clientID","status","message") values ('7','7','2','sent','Your account is overdrawn.');
Insert into C##JAVA_BANK."Notification" (ID,"bank_accountID","clientID","status","message") values ('8','8','3','read','A suspicious transaction has been detected on your account.');
Insert into C##JAVA_BANK."Notification" (ID,"bank_accountID","clientID","status","message") values ('9','9','4','archived','Your account has been debited for fees.');
Insert into C##JAVA_BANK."Notification" (ID,"bank_accountID","clientID","status","message") values ('10','10','5','sent','Your account is now active.');
REM INSERTING into C##JAVA_BANK."SavingAccount"
SET DEFINE OFF;
Insert into C##JAVA_BANK."SavingAccount" ("bank_accountID","interest_rate") values ('6','0,0275');
Insert into C##JAVA_BANK."SavingAccount" ("bank_accountID","interest_rate") values ('7','0,01');
Insert into C##JAVA_BANK."SavingAccount" ("bank_accountID","interest_rate") values ('8','0,0325');
Insert into C##JAVA_BANK."SavingAccount" ("bank_accountID","interest_rate") values ('9','0,02');
Insert into C##JAVA_BANK."SavingAccount" ("bank_accountID","interest_rate") values ('10','0,025');
REM INSERTING into C##JAVA_BANK."Task"
SET DEFINE OFF;
Insert into C##JAVA_BANK."Task" (ID,"status","action_type") values ('1','pending','creation');
Insert into C##JAVA_BANK."Task" (ID,"status","action_type") values ('2','in_progress','creation');
Insert into C##JAVA_BANK."Task" (ID,"status","action_type") values ('3','accepted','creation');
Insert into C##JAVA_BANK."Task" (ID,"status","action_type") values ('4','rejected','creation');
Insert into C##JAVA_BANK."Task" (ID,"status","action_type") values ('5','completed','creation');
Insert into C##JAVA_BANK."Task" (ID,"status","action_type") values ('6','pending','creation');
Insert into C##JAVA_BANK."Task" (ID,"status","action_type") values ('7','in_progress','creation');
Insert into C##JAVA_BANK."Task" (ID,"status","action_type") values ('8','accepted','creation');
Insert into C##JAVA_BANK."Task" (ID,"status","action_type") values ('9','rejected','deletion');
Insert into C##JAVA_BANK."Task" (ID,"status","action_type") values ('10','completed','deletion');
Insert into C##JAVA_BANK."Task" (ID,"status","action_type") values ('11','pending','creation');
Insert into C##JAVA_BANK."Task" (ID,"status","action_type") values ('12','in_progress','creation');
Insert into C##JAVA_BANK."Task" (ID,"status","action_type") values ('13','accepted','creation');
Insert into C##JAVA_BANK."Task" (ID,"status","action_type") values ('14','rejected','creation');
Insert into C##JAVA_BANK."Task" (ID,"status","action_type") values ('15','completed','creation');
Insert into C##JAVA_BANK."Task" (ID,"status","action_type") values ('16','pending','creation');
Insert into C##JAVA_BANK."Task" (ID,"status","action_type") values ('17','in_progress','creation');
Insert into C##JAVA_BANK."Task" (ID,"status","action_type") values ('18','accepted','creation');
Insert into C##JAVA_BANK."Task" (ID,"status","action_type") values ('19','rejected','deletion');
Insert into C##JAVA_BANK."Task" (ID,"status","action_type") values ('20','completed','deletion');
REM INSERTING into C##JAVA_BANK."TransactionRecord"
SET DEFINE OFF;
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('1','1','deposit','100',to_date('23-01-02','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('2','1','withdrawal','200',to_date('23-01-03','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('3','1','deposit','300',to_date('23-01-04','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('4','1','withdrawal','400',to_date('23-01-05','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('5','1','deposit','500',to_date('23-01-06','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('6','2','deposit','100',to_date('23-01-05','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('7','2','withdrawal','200',to_date('23-01-06','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('8','2','deposit','300',to_date('23-01-07','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('9','2','withdrawal','400',to_date('23-01-08','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('10','2','deposit','500',to_date('23-01-09','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('11','3','deposit','100',to_date('23-01-08','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('12','3','withdrawal','200',to_date('23-01-09','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('13','3','deposit','300',to_date('23-01-10','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('14','3','withdrawal','400',to_date('23-01-11','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('15','3','deposit','500',to_date('23-01-12','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('16','4','deposit','100',to_date('23-01-11','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('17','4','withdrawal','200',to_date('23-01-12','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('18','4','deposit','300',to_date('23-01-13','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('19','4','withdrawal','400',to_date('23-01-14','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('20','4','deposit','500',to_date('23-01-15','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('21','5','deposit','100',to_date('23-01-14','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('22','5','withdrawal','200',to_date('23-01-15','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('23','5','deposit','300',to_date('23-01-16','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('24','5','withdrawal','400',to_date('23-01-17','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('25','5','deposit','500',to_date('23-01-18','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('26','6','deposit','100',to_date('23-01-17','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('27','6','withdrawal','200',to_date('23-01-18','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('28','6','deposit','300',to_date('23-01-19','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('29','6','withdrawal','400',to_date('23-01-20','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('30','6','deposit','500',to_date('23-01-21','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('31','7','deposit','100',to_date('23-01-20','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('32','7','withdrawal','200',to_date('23-01-21','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('33','7','deposit','300',to_date('23-01-22','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('34','7','withdrawal','400',to_date('23-01-23','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('35','7','deposit','500',to_date('23-01-24','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('36','8','deposit','100',to_date('23-01-23','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('37','8','withdrawal','200',to_date('23-01-24','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('38','8','deposit','300',to_date('23-01-25','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('39','8','withdrawal','400',to_date('23-01-26','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('40','8','deposit','500',to_date('23-01-27','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('41','9','deposit','100',to_date('23-01-26','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('42','9','withdrawal','200',to_date('23-01-27','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('43','9','deposit','300',to_date('23-01-28','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('44','9','withdrawal','400',to_date('23-01-29','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('45','9','deposit','500',to_date('23-01-30','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('46','10','deposit','100',to_date('23-01-29','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('47','10','withdrawal','200',to_date('23-01-30','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('48','10','deposit','300',to_date('23-01-31','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('49','10','withdrawal','400',to_date('23-02-01','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('50','10','deposit','500',to_date('23-02-02','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('51','11','deposit','100',to_date('23-02-01','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('52','11','withdrawal','200',to_date('23-02-02','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('53','11','deposit','300',to_date('23-02-03','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('54','11','withdrawal','400',to_date('23-02-04','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('55','11','deposit','500',to_date('23-02-05','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('56','12','deposit','100',to_date('23-02-04','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('57','12','withdrawal','200',to_date('23-02-05','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('58','12','deposit','300',to_date('23-02-06','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('59','12','withdrawal','400',to_date('23-02-07','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('60','12','deposit','500',to_date('23-02-08','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('61','13','deposit','100',to_date('23-02-07','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('62','13','withdrawal','200',to_date('23-02-08','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('63','13','deposit','300',to_date('23-02-09','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('64','13','withdrawal','400',to_date('23-02-10','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('65','13','deposit','500',to_date('23-02-11','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('66','14','deposit','100',to_date('23-02-10','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('67','14','withdrawal','200',to_date('23-02-11','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('68','14','deposit','300',to_date('23-02-12','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('69','14','withdrawal','400',to_date('23-02-13','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('70','14','deposit','500',to_date('23-02-14','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('71','15','deposit','100',to_date('23-02-13','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('72','15','withdrawal','200',to_date('23-02-14','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('73','15','deposit','300',to_date('23-02-15','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('74','15','withdrawal','400',to_date('23-02-16','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('75','15','deposit','500',to_date('23-02-17','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('76','16','deposit','100',to_date('23-02-16','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('77','16','withdrawal','200',to_date('23-02-17','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('78','16','deposit','300',to_date('23-02-18','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('79','16','withdrawal','400',to_date('23-02-19','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('80','16','deposit','500',to_date('23-02-20','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('81','17','deposit','100',to_date('23-02-19','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('82','17','withdrawal','200',to_date('23-02-20','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('83','17','deposit','300',to_date('23-02-21','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('84','17','withdrawal','400',to_date('23-02-22','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('85','17','deposit','500',to_date('23-02-23','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('86','18','deposit','100',to_date('23-02-22','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('87','18','withdrawal','200',to_date('23-02-23','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('88','18','deposit','300',to_date('23-02-24','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('89','18','withdrawal','400',to_date('23-02-25','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('90','18','deposit','500',to_date('23-02-26','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('91','19','deposit','100',to_date('23-02-25','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('92','19','withdrawal','200',to_date('23-02-26','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('93','19','deposit','300',to_date('23-02-27','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('94','19','withdrawal','400',to_date('23-02-28','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('95','19','deposit','500',to_date('23-03-01','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('96','20','deposit','100',to_date('23-02-28','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('97','20','withdrawal','200',to_date('23-03-01','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('98','20','deposit','300',to_date('23-03-02','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('99','20','withdrawal','400',to_date('23-03-03','RR-MM-DD'),'0');
Insert into C##JAVA_BANK."TransactionRecord" ("historicID","bank_accountID","type","operation","date","balance") values ('100','20','deposit','500',to_date('23-03-04','RR-MM-DD'),'0');
REM INSERTING into C##JAVA_BANK."User"
SET DEFINE OFF;
Insert into C##JAVA_BANK."User" (ID,"firstname","lastname","nip","address","telephone","email") values ('1','John','Doe','123456789','123 Main St','555-1234','john.doe@example.com');
Insert into C##JAVA_BANK."User" (ID,"firstname","lastname","nip","address","telephone","email") values ('2','Jane','Smith','987654321','456 Oak Ave','555-5678','jane.smith@example.com');
Insert into C##JAVA_BANK."User" (ID,"firstname","lastname","nip","address","telephone","email") values ('3','Robert','Jones','112233445','789 Pine Ln','555-9012','robert.jones@example.com');
Insert into C##JAVA_BANK."User" (ID,"firstname","lastname","nip","address","telephone","email") values ('4','Emily','Brown','667788990','321 Elm Rd','555-3456','emily.brown@example.com');
Insert into C##JAVA_BANK."User" (ID,"firstname","lastname","nip","address","telephone","email") values ('5','Michael','Davis','445566778','654 Maple Dr','555-7890','michael.davis@example.com');
Insert into C##JAVA_BANK."User" (ID,"firstname","lastname","nip","address","telephone","email") values ('6','Jessica','Wilson','889900112','987 Cedar Ct','555-2345','jessica.wilson@example.com');
Insert into C##JAVA_BANK."User" (ID,"firstname","lastname","nip","address","telephone","email") values ('7','David','Garcia','223344556','210 Birch St','555-6789','david.garcia@example.com');
Insert into C##JAVA_BANK."User" (ID,"firstname","lastname","nip","address","telephone","email") values ('8','Ashley','Rodriguez','778899001','543 Walnut Ave','555-0123','ashley.rodriguez@example.com');
Insert into C##JAVA_BANK."User" (ID,"firstname","lastname","nip","address","telephone","email") values ('9','Christopher','Williams','334455667','876 Cherry Ln','555-4567','christopher.williams@example.com');
Insert into C##JAVA_BANK."User" (ID,"firstname","lastname","nip","address","telephone","email") values ('10','Amanda','Martinez','556677889','109 Oak Rd','555-8901','amanda.martinez@example.com');
REM INSERTING into C##JAVA_BANK."UserTask"
SET DEFINE OFF;
Insert into C##JAVA_BANK."UserTask" ("taskID","userID","user_type") values ('1','1','client');
Insert into C##JAVA_BANK."UserTask" ("taskID","userID","user_type") values ('2','2','manager');
Insert into C##JAVA_BANK."UserTask" ("taskID","userID","user_type") values ('3','3','client');
Insert into C##JAVA_BANK."UserTask" ("taskID","userID","user_type") values ('4','4','manager');
Insert into C##JAVA_BANK."UserTask" ("taskID","userID","user_type") values ('5','5','client');
Insert into C##JAVA_BANK."UserTask" ("taskID","userID","user_type") values ('6','6','manager');
Insert into C##JAVA_BANK."UserTask" ("taskID","userID","user_type") values ('7','7','client');
Insert into C##JAVA_BANK."UserTask" ("taskID","userID","user_type") values ('8','8','manager');
Insert into C##JAVA_BANK."UserTask" ("taskID","userID","user_type") values ('9','9','client');
Insert into C##JAVA_BANK."UserTask" ("taskID","userID","user_type") values ('10','10','manager');
REM INSERTING into C##JAVA_BANK."AccountTaskView"
SET DEFINE OFF;
Insert into C##JAVA_BANK."AccountTaskView" ("taskID","bank_accountID","status","action_type") values ('11','1','pending','creation');
Insert into C##JAVA_BANK."AccountTaskView" ("taskID","bank_accountID","status","action_type") values ('12','2','in_progress','creation');
Insert into C##JAVA_BANK."AccountTaskView" ("taskID","bank_accountID","status","action_type") values ('13','3','accepted','creation');
Insert into C##JAVA_BANK."AccountTaskView" ("taskID","bank_accountID","status","action_type") values ('14','4','rejected','creation');
Insert into C##JAVA_BANK."AccountTaskView" ("taskID","bank_accountID","status","action_type") values ('15','5','completed','creation');
Insert into C##JAVA_BANK."AccountTaskView" ("taskID","bank_accountID","status","action_type") values ('16','6','pending','creation');
Insert into C##JAVA_BANK."AccountTaskView" ("taskID","bank_accountID","status","action_type") values ('17','7','in_progress','creation');
Insert into C##JAVA_BANK."AccountTaskView" ("taskID","bank_accountID","status","action_type") values ('18','8','accepted','creation');
Insert into C##JAVA_BANK."AccountTaskView" ("taskID","bank_accountID","status","action_type") values ('19','9','rejected','deletion');
Insert into C##JAVA_BANK."AccountTaskView" ("taskID","bank_accountID","status","action_type") values ('20','10','completed','deletion');
REM INSERTING into C##JAVA_BANK."ActiveBankAccountView"
SET DEFINE OFF;
Insert into C##JAVA_BANK."ActiveBankAccountView" (ID,"userID","balance","creation_date") values ('2','2','2500,5',to_date('23-02-20','RR-MM-DD'));
Insert into C##JAVA_BANK."ActiveBankAccountView" (ID,"userID","balance","creation_date") values ('3','3','500,75',to_date('23-03-10','RR-MM-DD'));
Insert into C##JAVA_BANK."ActiveBankAccountView" (ID,"userID","balance","creation_date") values ('5','5','750,25',to_date('23-05-05','RR-MM-DD'));
Insert into C##JAVA_BANK."ActiveBankAccountView" (ID,"userID","balance","creation_date") values ('7','2','2500,5',to_date('23-02-20','RR-MM-DD'));
Insert into C##JAVA_BANK."ActiveBankAccountView" (ID,"userID","balance","creation_date") values ('8','3','500,75',to_date('23-03-10','RR-MM-DD'));
REM INSERTING into C##JAVA_BANK."ActiveUserView"
SET DEFINE OFF;
Insert into C##JAVA_BANK."ActiveUserView" (ID,"firstname","lastname","nip","address","telephone","email") values ('3','Robert','Jones','112233445','789 Pine Ln','555-9012','robert.jones@example.com');
Insert into C##JAVA_BANK."ActiveUserView" (ID,"firstname","lastname","nip","address","telephone","email") values ('5','Michael','Davis','445566778','654 Maple Dr','555-7890','michael.davis@example.com');
Insert into C##JAVA_BANK."ActiveUserView" (ID,"firstname","lastname","nip","address","telephone","email") values ('8','Ashley','Rodriguez','778899001','543 Walnut Ave','555-0123','ashley.rodriguez@example.com');
REM INSERTING into C##JAVA_BANK."CheckingAccountView"
SET DEFINE OFF;
Insert into C##JAVA_BANK."CheckingAccountView" (CHECKING_ACCOUNTID,"userID","balance","creation_date","transaction_fee") values ('2','2','2500,5',to_date('23-02-20','RR-MM-DD'),'1,5');
Insert into C##JAVA_BANK."CheckingAccountView" (CHECKING_ACCOUNTID,"userID","balance","creation_date","transaction_fee") values ('3','3','500,75',to_date('23-03-10','RR-MM-DD'),'0,75');
Insert into C##JAVA_BANK."CheckingAccountView" (CHECKING_ACCOUNTID,"userID","balance","creation_date","transaction_fee") values ('5','5','750,25',to_date('23-05-05','RR-MM-DD'),'1,25');
REM INSERTING into C##JAVA_BANK."ClientView"
SET DEFINE OFF;
Insert into C##JAVA_BANK."ClientView" (CLIENTID,"firstname","lastname","nip","address","telephone","email") values ('3','Robert','Jones','112233445','789 Pine Ln','555-9012','robert.jones@example.com');
Insert into C##JAVA_BANK."ClientView" (CLIENTID,"firstname","lastname","nip","address","telephone","email") values ('5','Michael','Davis','445566778','654 Maple Dr','555-7890','michael.davis@example.com');
REM INSERTING into C##JAVA_BANK."CreditAccountView"
SET DEFINE OFF;
REM INSERTING into C##JAVA_BANK."CurrencyAccountView"
SET DEFINE OFF;
REM INSERTING into C##JAVA_BANK."ManagerView"
SET DEFINE OFF;
Insert into C##JAVA_BANK."ManagerView" (MANAGERID,"firstname","lastname","nip","address","telephone","email","role") values ('8','Ashley','Rodriguez','778899001','543 Walnut Ave','555-0123','ashley.rodriguez@example.com','Sales Manager');
REM INSERTING into C##JAVA_BANK."RemovedBankAccountView"
SET DEFINE OFF;
Insert into C##JAVA_BANK."RemovedBankAccountView" (ID,"userID","balance","creation_date") values ('10','5','750,25',to_date('23-05-05','RR-MM-DD'));
REM INSERTING into C##JAVA_BANK."RemovedUserView"
SET DEFINE OFF;
Insert into C##JAVA_BANK."RemovedUserView" (ID,"firstname","lastname","nip","address","telephone","email") values ('10','Amanda','Martinez','556677889','109 Oak Rd','555-8901','amanda.martinez@example.com');
REM INSERTING into C##JAVA_BANK."SavingAccountView"
SET DEFINE OFF;
Insert into C##JAVA_BANK."SavingAccountView" (SAVING_ACCOUNTID,"userID","balance","creation_date","interest_rate") values ('7','2','2500,5',to_date('23-02-20','RR-MM-DD'),'0,01');
Insert into C##JAVA_BANK."SavingAccountView" (SAVING_ACCOUNTID,"userID","balance","creation_date","interest_rate") values ('8','3','500,75',to_date('23-03-10','RR-MM-DD'),'0,0325');
REM INSERTING into C##JAVA_BANK."UserTaskView"
SET DEFINE OFF;
Insert into C##JAVA_BANK."UserTaskView" ("taskID","status","action_type","userID","user_type") values ('1','pending','creation','1','client');
Insert into C##JAVA_BANK."UserTaskView" ("taskID","status","action_type","userID","user_type") values ('2','in_progress','creation','2','manager');
Insert into C##JAVA_BANK."UserTaskView" ("taskID","status","action_type","userID","user_type") values ('3','accepted','creation','3','client');
Insert into C##JAVA_BANK."UserTaskView" ("taskID","status","action_type","userID","user_type") values ('4','rejected','creation','4','manager');
Insert into C##JAVA_BANK."UserTaskView" ("taskID","status","action_type","userID","user_type") values ('5','completed','creation','5','client');
Insert into C##JAVA_BANK."UserTaskView" ("taskID","status","action_type","userID","user_type") values ('6','pending','creation','6','manager');
Insert into C##JAVA_BANK."UserTaskView" ("taskID","status","action_type","userID","user_type") values ('7','in_progress','creation','7','client');
Insert into C##JAVA_BANK."UserTaskView" ("taskID","status","action_type","userID","user_type") values ('8','accepted','creation','8','manager');
Insert into C##JAVA_BANK."UserTaskView" ("taskID","status","action_type","userID","user_type") values ('9','rejected','deletion','9','client');
Insert into C##JAVA_BANK."UserTaskView" ("taskID","status","action_type","userID","user_type") values ('10','completed','deletion','10','manager');
--------------------------------------------------------
--  DDL for Index SYS_C008328
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JAVA_BANK"."SYS_C008328" ON "C##JAVA_BANK"."User" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008329
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JAVA_BANK"."SYS_C008329" ON "C##JAVA_BANK"."User" ("email") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008330
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JAVA_BANK"."SYS_C008330" ON "C##JAVA_BANK"."Client" ("userID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008333
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JAVA_BANK"."SYS_C008333" ON "C##JAVA_BANK"."Manager" ("userID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008338
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JAVA_BANK"."SYS_C008338" ON "C##JAVA_BANK"."BankAccount" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008341
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JAVA_BANK"."SYS_C008341" ON "C##JAVA_BANK"."CheckingAccount" ("bank_accountID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008344
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JAVA_BANK"."SYS_C008344" ON "C##JAVA_BANK"."SavingAccount" ("bank_accountID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008349
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JAVA_BANK"."SYS_C008349" ON "C##JAVA_BANK"."CurrencyAccount" ("bank_accountID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008353
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JAVA_BANK"."SYS_C008353" ON "C##JAVA_BANK"."CreditAccount" ("bank_accountID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008360
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JAVA_BANK"."SYS_C008360" ON "C##JAVA_BANK"."TransactionRecord" ("bank_accountID", "historicID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008367
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JAVA_BANK"."SYS_C008367" ON "C##JAVA_BANK"."Notification" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008375
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JAVA_BANK"."SYS_C008375" ON "C##JAVA_BANK"."Task" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008379
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JAVA_BANK"."SYS_C008379" ON "C##JAVA_BANK"."UserTask" ("taskID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008383
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JAVA_BANK"."SYS_C008383" ON "C##JAVA_BANK"."AccountTask" ("taskID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008383
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JAVA_BANK"."SYS_C008383" ON "C##JAVA_BANK"."AccountTask" ("taskID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008338
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JAVA_BANK"."SYS_C008338" ON "C##JAVA_BANK"."BankAccount" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008341
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JAVA_BANK"."SYS_C008341" ON "C##JAVA_BANK"."CheckingAccount" ("bank_accountID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008330
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JAVA_BANK"."SYS_C008330" ON "C##JAVA_BANK"."Client" ("userID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008353
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JAVA_BANK"."SYS_C008353" ON "C##JAVA_BANK"."CreditAccount" ("bank_accountID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008349
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JAVA_BANK"."SYS_C008349" ON "C##JAVA_BANK"."CurrencyAccount" ("bank_accountID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008333
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JAVA_BANK"."SYS_C008333" ON "C##JAVA_BANK"."Manager" ("userID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008367
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JAVA_BANK"."SYS_C008367" ON "C##JAVA_BANK"."Notification" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008344
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JAVA_BANK"."SYS_C008344" ON "C##JAVA_BANK"."SavingAccount" ("bank_accountID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008375
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JAVA_BANK"."SYS_C008375" ON "C##JAVA_BANK"."Task" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008360
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JAVA_BANK"."SYS_C008360" ON "C##JAVA_BANK"."TransactionRecord" ("bank_accountID", "historicID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008328
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JAVA_BANK"."SYS_C008328" ON "C##JAVA_BANK"."User" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008329
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JAVA_BANK"."SYS_C008329" ON "C##JAVA_BANK"."User" ("email") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Index SYS_C008379
--------------------------------------------------------

  CREATE UNIQUE INDEX "C##JAVA_BANK"."SYS_C008379" ON "C##JAVA_BANK"."UserTask" ("taskID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Procedure ARCHIVENOTIFICATION
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##JAVA_BANK"."ARCHIVENOTIFICATION" (
        p_ID INT
) AS
BEGIN
        UpdateNotification(p_ID, 'archived');
        DBMS_OUTPUT.PUT_LINE('Notification archived successfully.');    
EXCEPTION
        WHEN OTHERS THEN
                DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
                ROLLBACK;
END ArchiveNotification;

/
--------------------------------------------------------
--  DDL for Procedure CREATEACCOUNTTASK
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##JAVA_BANK"."CREATEACCOUNTTASK" (
    p_bank_accountID INT,
    p_action_type VARCHAR2,
    p_status VARCHAR2 := 'pending'
) AS
    v_taskID INT;
BEGIN
    -- Insert into Task table
    INSERT INTO "Task" ("status", "action_type")
    VALUES (p_status, p_action_type)
    RETURNING "ID" INTO v_taskID;

    -- Insert into AccountTask table
    INSERT INTO "AccountTask" ("taskID", "bank_accountID")
    VALUES (v_taskID, p_bank_accountID);

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('AccountTask created successfully with task ID: ' || v_taskID);
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END CreateAccountTask;

/
--------------------------------------------------------
--  DDL for Procedure CREATECHECKINGACCOUNT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##JAVA_BANK"."CREATECHECKINGACCOUNT" (
    p_userID INT,
    p_transaction_fee DECIMAL,
    p_balance DECIMAL := 0.00,
    p_creation_date DATE := SYSDATE
) AS
    v_bank_accountID INT;
BEGIN
    -- Insert into BankAccount table
    INSERT INTO "BankAccount" ("userID", "balance", "creation_date")
    VALUES (p_userID, p_balance, p_creation_date)
    RETURNING "ID" INTO v_bank_accountID;

    -- Insert into CheckingAccount table
    INSERT INTO "CheckingAccount" ("bank_accountID", "transaction_fee")
    VALUES (v_bank_accountID, p_transaction_fee);

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Checking Account created successfully with Bank Account ID: ' || v_bank_accountID);
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END CreateCheckingAccount;

/
--------------------------------------------------------
--  DDL for Procedure CREATECLIENT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##JAVA_BANK"."CREATECLIENT" (
    p_firstname VARCHAR2,
    p_lastname VARCHAR2,
    p_nip VARCHAR2,
    p_address VARCHAR2,
    p_telephone VARCHAR2,
    p_email VARCHAR2
) AS
    v_user_id INT;
BEGIN
    -- Insert into User table
    INSERT INTO "User" ("firstname", "lastname", "nip", "address", "telephone", "email")
    VALUES (p_firstname, p_lastname, p_nip, p_address, p_telephone, p_email)
    RETURNING "ID" INTO v_user_id;

    -- Insert into Client table
    INSERT INTO "Client" ("userID")
    VALUES (v_user_id);

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Client created successfully with User ID: ' || v_user_id);
EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        DBMS_OUTPUT.PUT_LINE('Error: Email already exists.');
        ROLLBACK;
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END CreateClient;

/
--------------------------------------------------------
--  DDL for Procedure CREATECREDITACCOUNT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##JAVA_BANK"."CREATECREDITACCOUNT" (
    p_userID INT,
    p_interest_rate DECIMAL,
    p_balance DECIMAL := 0.00,
    p_creation_date DATE := SYSDATE
) AS
    v_bank_accountID INT;
BEGIN
    -- Insert into BankAccount table
    INSERT INTO "BankAccount" ("userID", "balance", "creation_date")
    VALUES (p_userID, p_balance, p_creation_date)
    RETURNING "ID" INTO v_bank_accountID;

    -- Insert into CreditAccount table
    INSERT INTO "CreditAccount" ("bank_accountID", "interest_rate")
    VALUES (v_bank_accountID, p_interest_rate);

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Credit Account created successfully with Bank Account ID: ' || v_bank_accountID);
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END CreateCreditAccount;

/
--------------------------------------------------------
--  DDL for Procedure CREATECURRENCYACCOUNT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##JAVA_BANK"."CREATECURRENCYACCOUNT" (
    p_userID INT,
    p_currency VARCHAR2,
    p_exchange_rate DECIMAL,
    p_balance DECIMAL := 0.00,
    p_creation_date DATE := SYSDATE
) AS
    v_bank_accountID INT;
BEGIN
    -- Insert into BankAccount table
    INSERT INTO "BankAccount" ("userID", "balance", "creation_date")
    VALUES (p_userID, p_balance, p_creation_date)
    RETURNING "ID" INTO v_bank_accountID;

    -- Insert into CurrencyAccount table
    INSERT INTO "CurrencyAccount" ("bank_accountID", "currency", "exchange_rate")
    VALUES (v_bank_accountID, p_currency, p_exchange_rate);

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Currency Account created successfully with Bank Account ID: ' || v_bank_accountID);
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END CreateCurrencyAccount;

/
--------------------------------------------------------
--  DDL for Procedure CREATEMANAGER
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##JAVA_BANK"."CREATEMANAGER" (
    p_firstname VARCHAR2,
    p_lastname VARCHAR2,
    p_nip VARCHAR2,
    p_address VARCHAR2,
    p_telephone VARCHAR2,
    p_email VARCHAR2,
    p_role VARCHAR2
) AS
    v_user_id INT;
BEGIN
    -- Insert into User table
    INSERT INTO "User" ("firstname", "lastname", "nip", "address", "telephone", "email")
    VALUES (p_firstname, p_lastname, p_nip, p_address, p_telephone, p_email)
    RETURNING "ID" INTO v_user_id;

    -- Insert into Manager table
    INSERT INTO "Manager" ("userID", "role")
    VALUES (v_user_id, p_role);

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Manager created successfully with User ID: ' || v_user_id);
EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        DBMS_OUTPUT.PUT_LINE('Error: Email already exists.');
        ROLLBACK;
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END CreateManager;

/
--------------------------------------------------------
--  DDL for Procedure CREATENOTIFICATION
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##JAVA_BANK"."CREATENOTIFICATION" (
        p_bank_accountID INT,
        p_clientID INT,
        p_message VARCHAR2,
        p_status VARCHAR2 := 'sent'
) AS 
BEGIN
        -- Insert into Notification table
        INSERT INTO "Notification" ("bank_accountID", "clientID", "message", "status")
        VALUES (p_bank_accountID, p_clientID, p_message, p_status);

        COMMIT;
EXCEPTION
        WHEN OTHERS THEN
                DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
                ROLLBACK;
END CreateNotification;

/
--------------------------------------------------------
--  DDL for Procedure CREATESAVINGACCOUNT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##JAVA_BANK"."CREATESAVINGACCOUNT" (
    p_userID INT,
    p_interest_rate DECIMAL,
    p_balance DECIMAL := 0.00,
    p_creation_date DATE := SYSDATE
) AS
    v_bank_accountID INT;
BEGIN
    -- Insert into BankAccount table
    INSERT INTO "BankAccount" ("userID", "balance", "creation_date")
    VALUES (p_userID, p_balance, p_creation_date)
    RETURNING "ID" INTO v_bank_accountID;

    -- Insert into SavingAccount table
    INSERT INTO "SavingAccount" ("bank_accountID", "interest_rate")
    VALUES (v_bank_accountID, p_interest_rate);

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Saving Account created successfully with Bank Account ID: ' || v_bank_accountID);
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END CreateSavingAccount;

/
--------------------------------------------------------
--  DDL for Procedure CREATETRANSACTIONRECORD
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##JAVA_BANK"."CREATETRANSACTIONRECORD" (
        p_bank_accountID INT,
        p_type VARCHAR2,
        p_balance DECIMAL,
        p_operation DECIMAL,
        p_date DATE := SYSDATE
) AS
BEGIN
        -- Insert into TransactionRecord table
        INSERT INTO "TransactionRecord" ("bank_accountID", "type", "balance", "operation", "date")
        VALUES (p_bank_accountID, p_type, p_balance, p_operation, p_date);

        COMMIT;
EXCEPTION
        WHEN OTHERS THEN
                DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
                ROLLBACK;
END CreateTransactionRecord;

/
--------------------------------------------------------
--  DDL for Procedure CREATEUSERTASK
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##JAVA_BANK"."CREATEUSERTASK" (
    p_userID INT,
    p_action_type VARCHAR2,
    p_user_type VARCHAR2,
    p_status VARCHAR2 := 'pending'
) AS
    v_taskID INT;
BEGIN
    -- Insert into Task table
    INSERT INTO "Task" ("status", "action_type")
    VALUES (p_status, p_action_type)
    RETURNING "ID" INTO v_taskID;

    -- Insert into ClientTask table
    INSERT INTO "UserTask" ("taskID", "userID", "user_type")
    VALUES (v_taskID, p_userID, p_user_type);

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('ClientTask created successfully with task ID: ' || v_taskID);
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END CreateUserTask;

/
--------------------------------------------------------
--  DDL for Procedure DELETECHECKINGACCOUNT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##JAVA_BANK"."DELETECHECKINGACCOUNT" (
    p_bank_accountID INT
) AS
BEGIN
    DELETE FROM "BankAccount"
    WHERE "ID" = p_bank_accountID;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Checking Account deleted successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END DeleteCheckingAccount;

/
--------------------------------------------------------
--  DDL for Procedure DELETECLIENT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##JAVA_BANK"."DELETECLIENT" (
    p_user_id INT
) AS
BEGIN
    DELETE FROM "User"
    WHERE "ID" = p_user_id;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Client deleted successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END DeleteClient;

/
--------------------------------------------------------
--  DDL for Procedure DELETECREDITACCOUNT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##JAVA_BANK"."DELETECREDITACCOUNT" (
    p_bank_accountID INT
) AS
BEGIN
    DELETE FROM "BankAccount"
    WHERE "ID" = p_bank_accountID;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Credit Account deleted successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END DeleteCreditAccount;

/
--------------------------------------------------------
--  DDL for Procedure DELETECURRENCYACCOUNT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##JAVA_BANK"."DELETECURRENCYACCOUNT" (
    p_bank_accountID INT
) AS
BEGIN
    DELETE FROM "BankAccount"
    WHERE "ID" = p_bank_accountID;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Currency Account deleted successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END DeleteCurrencyAccount;

/
--------------------------------------------------------
--  DDL for Procedure DELETEMANAGER
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##JAVA_BANK"."DELETEMANAGER" (
    p_user_id INT
) AS
BEGIN
    DELETE FROM "User"
    WHERE "ID" = p_user_id;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Manager deleted successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END DeleteManager;

/
--------------------------------------------------------
--  DDL for Procedure DELETESAVINGACCOUNT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##JAVA_BANK"."DELETESAVINGACCOUNT" (
    p_bank_accountID INT
) AS
BEGIN
    DELETE FROM "BankAccount"
    WHERE "ID" = p_bank_accountID;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Saving Account deleted successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END DeleteSavingAccount;

/
--------------------------------------------------------
--  DDL for Procedure DELETEUSERTASK
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##JAVA_BANK"."DELETEUSERTASK" (
    p_taskID INT
) AS
BEGIN
    DELETE FROM "Task"
    WHERE "ID" = p_taskID;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('ClientTask deleted successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END;

/
--------------------------------------------------------
--  DDL for Procedure SETNOTIFICATIONTOREAD
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##JAVA_BANK"."SETNOTIFICATIONTOREAD" (
        p_ID INT
) AS
BEGIN
        UpdateNotification(p_ID, 'read');
        DBMS_OUTPUT.PUT_LINE('Notification read successfully.');
EXCEPTION
        WHEN OTHERS THEN
                DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
                ROLLBACK;
END SetNotificationToRead;

/
--------------------------------------------------------
--  DDL for Procedure UPDATEACCOUNTTASK
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##JAVA_BANK"."UPDATEACCOUNTTASK" (
    p_taskID INT,
    p_status VARCHAR2
) AS
BEGIN
    UPDATE "Task"
    SET
        "status" = NVL(p_status, "status")
    WHERE "ID" = p_taskID;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('AccountTask updated successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END UpdateAccountTask;

/
--------------------------------------------------------
--  DDL for Procedure UPDATECHECKINGACCOUNT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##JAVA_BANK"."UPDATECHECKINGACCOUNT" (
    p_bank_accountID INT,
    p_balance DECIMAL := NULL,
    p_creation_date DATE := NULL,
    p_transaction_fee DECIMAL := NULL
) AS
BEGIN
    UPDATE "BankAccount"
    SET
        "balance" = NVL(p_balance, "balance"),
        "creation_date" = NVL(p_creation_date, "creation_date")
    WHERE "ID" = p_bank_accountID;

    UPDATE "CheckingAccount"
    SET
        "transaction_fee" = NVL(p_transaction_fee, "transaction_fee")
    WHERE "bank_accountID" = p_bank_accountID;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Checking Account updated successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END UpdateCheckingAccount;

/
--------------------------------------------------------
--  DDL for Procedure UPDATECLIENT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##JAVA_BANK"."UPDATECLIENT" (
    p_client_id INT,
    p_firstname VARCHAR2 := NULL,
    p_lastname VARCHAR2 := NULL,
    p_nip VARCHAR2 := NULL,
    p_address VARCHAR2 := NULL,
    p_telephone VARCHAR2 := NULL,
    p_email VARCHAR2 := NULL
) AS
BEGIN
    UPDATE "User"
    SET
        "firstname" = NVL(p_firstname, "firstname"),
        "lastname" = NVL(p_lastname, "lastname"),
        "nip" = NVL(p_nip, "nip"),
        "address" = NVL(p_address, "address"),
        "telephone" = NVL(p_telephone, "telephone"),
        "email" = NVL(p_email, "email")
    WHERE "ID" = p_client_id;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Client updated successfully.');
EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        DBMS_OUTPUT.PUT_LINE('Error: Email already exists.');
        ROLLBACK;
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END UpdateClient;

/
--------------------------------------------------------
--  DDL for Procedure UPDATECREDITACCOUNT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##JAVA_BANK"."UPDATECREDITACCOUNT" (
    p_bank_accountID INT,
    p_balance DECIMAL := NULL,
    p_creation_date DATE := NULL,
    p_interest_rate DECIMAL := NULL
) AS
BEGIN
    UPDATE "BankAccount"
    SET
        "balance" = NVL(p_balance, "balance"),
        "creation_date" = NVL(p_creation_date, "creation_date")
    WHERE "ID" = p_bank_accountID;

    UPDATE "CreditAccount"
    SET
        "interest_rate" = NVL(p_interest_rate, "interest_rate")
    WHERE "bank_accountID" = p_bank_accountID;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Credit Account updated successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END UpdateCreditAccount;

/
--------------------------------------------------------
--  DDL for Procedure UPDATECURRENCYACCOUNT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##JAVA_BANK"."UPDATECURRENCYACCOUNT" (
    p_bank_accountID INT,
    p_balance DECIMAL := NULL,
    p_creation_date DATE := NULL,
    p_currency VARCHAR2 := NULL,
    p_exchange_rate DECIMAL := NULL
) AS
BEGIN
    UPDATE "BankAccount"
    SET
        "balance" = NVL(p_balance, "balance"),
        "creation_date" = NVL(p_creation_date, "creation_date")
    WHERE "ID" = p_bank_accountID;

    UPDATE "CurrencyAccount"
    SET
        "currency" = NVL(p_currency, "currency"),
        "exchange_rate" = NVL(p_exchange_rate, "exchange_rate")
    WHERE "bank_accountID" = p_bank_accountID;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Currency Account updated successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END UpdateCurrencyAccount;

/
--------------------------------------------------------
--  DDL for Procedure UPDATEMANAGER
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##JAVA_BANK"."UPDATEMANAGER" (
    p_user_id INT,
    p_firstname VARCHAR2 := NULL,
    p_lastname VARCHAR2 := NULL,
    p_nip VARCHAR2 := NULL,
    p_address VARCHAR2 := NULL,
    p_telephone VARCHAR2 := NULL,
    p_email VARCHAR2 := NULL,
    p_role VARCHAR2 := NULL
) AS
BEGIN
    UPDATE "User"
    SET
        "firstname" = NVL(p_firstname, "firstname"),
        "lastname" = NVL(p_lastname, "lastname"),
        "nip" = NVL(p_nip, "nip"),
        "address" = NVL(p_address, "address"),
        "telephone" = NVL(p_telephone, "telephone"),
        "email" = NVL(p_email, "email")
    WHERE "ID" = p_user_id;

    UPDATE "Manager"
    SET
        "role" = NVL(p_role, "role")
    WHERE "userID" = p_user_id;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Manager updated successfully.');
EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        DBMS_OUTPUT.PUT_LINE('Error: Email already exists.');
        ROLLBACK;
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END UpdateManager;

/
--------------------------------------------------------
--  DDL for Procedure UPDATENOTIFICATION
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##JAVA_BANK"."UPDATENOTIFICATION" (
        p_ID INT,
        p_status VARCHAR2
) AS
BEGIN
        UPDATE "Notification"
        SET "status" = p_status
        WHERE ID = p_ID;

        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Notification updated successfully.');
EXCEPTION
        WHEN OTHERS THEN
                DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
                ROLLBACK;
END UpdateNotification;

/
--------------------------------------------------------
--  DDL for Procedure UPDATESAVINGACCOUNT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##JAVA_BANK"."UPDATESAVINGACCOUNT" (
    p_bank_accountID INT,
    p_balance DECIMAL := NULL,
    p_creation_date DATE := NULL,
    p_interest_rate DECIMAL := NULL
) AS
BEGIN
    UPDATE "BankAccount"
    SET
        "balance" = NVL(p_balance, "balance"),
        "creation_date" = NVL(p_creation_date, "creation_date")
    WHERE "ID" = p_bank_accountID;

    UPDATE "SavingAccount"
    SET
        "interest_rate" = NVL(p_interest_rate, "interest_rate")
    WHERE "bank_accountID" = p_bank_accountID;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Saving Account updated successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END UpdateSavingAccount;

/
--------------------------------------------------------
--  DDL for Procedure UPDATEUSERTASK
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "C##JAVA_BANK"."UPDATEUSERTASK" (
    p_taskID INT,
    p_status VARCHAR2
) AS
BEGIN
    UPDATE "Task"
    SET
        "status" = NVL(p_status, "status")
    WHERE "ID" = p_taskID;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('ClientTask updated successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END UpdateUserTask;

/
--------------------------------------------------------
--  DDL for Function READACCOUNTTASKBYID
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##JAVA_BANK"."READACCOUNTTASKBYID" (
    p_taskID INT
) RETURN SYS_REFCURSOR AS
    accountTask_cursor SYS_REFCURSOR;
BEGIN
    OPEN accountTask_cursor FOR
    SELECT * FROM "AccountTaskView"
    WHERE "taskID" = p_taskID;

    RETURN accountTask_cursor;
END ReadAccountTaskByID;

/
--------------------------------------------------------
--  DDL for Function READALLACCOUNTTASKS
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##JAVA_BANK"."READALLACCOUNTTASKS" 
RETURN SYS_REFCURSOR AS
    accountTask_cursor SYS_REFCURSOR;
BEGIN
    OPEN accountTask_cursor FOR
    SELECT * FROM "AccountTaskView";

    RETURN accountTask_cursor;
END ReadAllAccountTasks;

/
--------------------------------------------------------
--  DDL for Function READALLCHECKINGACCOUNTS
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##JAVA_BANK"."READALLCHECKINGACCOUNTS" 
RETURN SYS_REFCURSOR AS
    checking_account_cursor SYS_REFCURSOR;
BEGIN
    OPEN checking_account_cursor FOR
    SELECT * FROM "CheckingAccountView";

    RETURN checking_account_cursor;
END ReadAllCheckingAccounts;

/
--------------------------------------------------------
--  DDL for Function READALLCLIENTS
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##JAVA_BANK"."READALLCLIENTS" 
RETURN SYS_REFCURSOR AS
    client_cursor SYS_REFCURSOR;
BEGIN
    OPEN client_cursor FOR
    SELECT * FROM "ClientView";

    RETURN client_cursor;
END ReadAllClients;

/
--------------------------------------------------------
--  DDL for Function READALLCREDITACCOUNTS
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##JAVA_BANK"."READALLCREDITACCOUNTS" 
RETURN SYS_REFCURSOR AS
    credit_account_cursor SYS_REFCURSOR;
BEGIN
    OPEN credit_account_cursor FOR
    SELECT * FROM "CreditAccountView";

    RETURN credit_account_cursor;
END ReadAllCreditAccounts;

/
--------------------------------------------------------
--  DDL for Function READALLCURRENCYACCOUNTS
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##JAVA_BANK"."READALLCURRENCYACCOUNTS" 
RETURN SYS_REFCURSOR AS
    currency_account_cursor SYS_REFCURSOR;
BEGIN
    OPEN currency_account_cursor FOR
    SELECT * FROM "CurrencyAccountView";

    RETURN currency_account_cursor;
END ReadAllCurrencyAccounts;

-- Procedure to create a new currency account

/
--------------------------------------------------------
--  DDL for Function READALLMANAGERS
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##JAVA_BANK"."READALLMANAGERS" 
RETURN SYS_REFCURSOR AS
    manager_cursor SYS_REFCURSOR;
BEGIN
    OPEN manager_cursor FOR
    SELECT * FROM "ManagerView";

    RETURN manager_cursor;
END ReadAllManagers;

/
--------------------------------------------------------
--  DDL for Function READALLNOTIFICATIONSFORBANKACCOUNT
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##JAVA_BANK"."READALLNOTIFICATIONSFORBANKACCOUNT" (
        p_bank_accountID INT
) RETURN SYS_REFCURSOR AS
        notification_cursor SYS_REFCURSOR;
BEGIN
        OPEN notification_cursor FOR
        SELECT * FROM "Notification"
        WHERE "bank_accountID" = p_bank_accountID
        AND "status" <> 'archived'
        ORDER BY ID ASC;

        RETURN notification_cursor;
END ReadAllNotificationsForBankAccount;

/
--------------------------------------------------------
--  DDL for Function READALLPENDINGACCOUNTTASKS
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##JAVA_BANK"."READALLPENDINGACCOUNTTASKS" 
RETURN SYS_REFCURSOR AS
    accountTask_cursor SYS_REFCURSOR;
BEGIN
    OPEN accountTask_cursor FOR
    SELECT * FROM "AccountTaskView"
    WHERE "status" = 'pending';

    RETURN accountTask_cursor;
END ReadAllPendingAccountTasks;

/
--------------------------------------------------------
--  DDL for Function READALLPENDINGUSERTASKS
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##JAVA_BANK"."READALLPENDINGUSERTASKS" 
RETURN SYS_REFCURSOR AS
    userTask_cursor SYS_REFCURSOR;
BEGIN
    OPEN userTask_cursor FOR
    SELECT * FROM "UserTaskView"
    WHERE "status" = 'pending';

    RETURN userTask_cursor;
END ReadAllPendingUserTasks;

/
--------------------------------------------------------
--  DDL for Function READALLSAVINGACCOUNTS
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##JAVA_BANK"."READALLSAVINGACCOUNTS" 
RETURN SYS_REFCURSOR AS
    saving_account_cursor SYS_REFCURSOR;
BEGIN
    OPEN saving_account_cursor FOR
    SELECT * FROM "SavingAccountView";

    RETURN saving_account_cursor;
END ReadAllSavingAccounts;

/
--------------------------------------------------------
--  DDL for Function READALLTRANSACTIONRECORDS
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##JAVA_BANK"."READALLTRANSACTIONRECORDS" 
RETURN SYS_REFCURSOR AS
        transaction_cursor SYS_REFCURSOR;
BEGIN
        OPEN transaction_cursor FOR
        SELECT * FROM "TransactionRecord"
        ORDER BY "historicID" ASC;

        RETURN transaction_cursor;
END ReadAllTransactionRecords;

/
--------------------------------------------------------
--  DDL for Function READALLUNREADNOTIFICATIONSFORCLIENT
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##JAVA_BANK"."READALLUNREADNOTIFICATIONSFORCLIENT" (
        p_clientID INT
) RETURN SYS_REFCURSOR AS
        notification_cursor SYS_REFCURSOR;
BEGIN
        OPEN notification_cursor FOR
        SELECT * FROM "Notification"
        WHERE "clientID" = p_clientID
        AND "status" = 'sent'
        ORDER BY ID ASC;

        RETURN notification_cursor;
END ReadAllUnreadNotificationsForClient;

/
--------------------------------------------------------
--  DDL for Function READALLUSERTASKS
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##JAVA_BANK"."READALLUSERTASKS" 
RETURN SYS_REFCURSOR AS
    userTask_cursor SYS_REFCURSOR;
BEGIN
    OPEN userTask_cursor FOR
    SELECT * FROM "UserTaskView";

    RETURN userTask_cursor;
END ReadAllUserTasks;

/
--------------------------------------------------------
--  DDL for Function READCHECKINGACCOUNTBYID
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##JAVA_BANK"."READCHECKINGACCOUNTBYID" (
    p_bank_accountID INT
) RETURN SYS_REFCURSOR AS
    checking_account_cursor SYS_REFCURSOR;
BEGIN
    OPEN checking_account_cursor FOR
    SELECT * FROM "CheckingAccountView"
    WHERE checking_accountID = p_bank_accountID;

    RETURN checking_account_cursor;
END ReadCheckingAccountByID;

/
--------------------------------------------------------
--  DDL for Function READCLIENTBYID
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##JAVA_BANK"."READCLIENTBYID" (
    p_user_id INT
) RETURN SYS_REFCURSOR AS
    client_cursor SYS_REFCURSOR;
BEGIN
    OPEN client_cursor FOR
    SELECT * FROM "ClientView"
    WHERE clientID = p_user_id;

    RETURN client_cursor;
END ReadClientByID;

/
--------------------------------------------------------
--  DDL for Function READCREDITACCOUNTBYID
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##JAVA_BANK"."READCREDITACCOUNTBYID" (
    p_bank_accountID INT
) RETURN SYS_REFCURSOR AS
    credit_account_cursor SYS_REFCURSOR;
BEGIN
    OPEN credit_account_cursor FOR
    SELECT * FROM "CreditAccountView"
    WHERE credit_accountID = p_bank_accountID;

    RETURN credit_account_cursor;
END ReadCreditAccountByID;

/
--------------------------------------------------------
--  DDL for Function READCURRENCYACCOUNTBYID
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##JAVA_BANK"."READCURRENCYACCOUNTBYID" (
    p_bank_accountID INT
) RETURN SYS_REFCURSOR AS
    currency_account_cursor SYS_REFCURSOR;
BEGIN
    OPEN currency_account_cursor FOR
    SELECT * FROM "CurrencyAccountView"
    WHERE currency_accountID = p_bank_accountID;

    RETURN currency_account_cursor;
END ReadCurrencyAccountByID;

/
--------------------------------------------------------
--  DDL for Function READMANAGERBYID
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##JAVA_BANK"."READMANAGERBYID" (
    p_user_id INT
) RETURN SYS_REFCURSOR AS
    manager_cursor SYS_REFCURSOR;
BEGIN
    OPEN manager_cursor FOR
    SELECT * FROM "ManagerView"
    WHERE managerID = p_user_id;

    RETURN manager_cursor;
END ReadManagerByID;

/
--------------------------------------------------------
--  DDL for Function READSAVINGACCOUNTBYID
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##JAVA_BANK"."READSAVINGACCOUNTBYID" (
    p_bank_accountID INT
) RETURN SYS_REFCURSOR AS
    saving_account_cursor SYS_REFCURSOR;
BEGIN
    OPEN saving_account_cursor FOR
    SELECT * FROM "SavingAccountView"
    WHERE saving_accountID = p_bank_accountID;

    RETURN saving_account_cursor;
END ReadSavingAccountByID;

/
--------------------------------------------------------
--  DDL for Function READTRANSACTIONRECORDFOR
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##JAVA_BANK"."READTRANSACTIONRECORDFOR" (
    bank_accountID INT
) return SYS_REFCURSOR AS
    transaction_cursor SYS_REFCURSOR;
BEGIN
    OPEN transaction_cursor FOR
    SELECT * FROM "TransactionRecord"
    WHERE bank_accountID = bank_accountID
    ORDER BY "historicID" ASC;

    RETURN transaction_cursor;
END ReadTransactionRecordFor;

/
--------------------------------------------------------
--  DDL for Function READUSERBYEMAIL
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##JAVA_BANK"."READUSERBYEMAIL" (
    p_email VARCHAR2
) RETURN SYS_REFCURSOR AS
    user_cursor SYS_REFCURSOR;
BEGIN
    OPEN user_cursor FOR
    SELECT * FROM "ActiveUserView"
    WHERE "email" = p_email;

    RETURN user_cursor;
END ReadUserByEmail;

/
--------------------------------------------------------
--  DDL for Function READUSERTASKBYID
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "C##JAVA_BANK"."READUSERTASKBYID" (
    p_taskID INT
) RETURN SYS_REFCURSOR AS
    userTask_cursor SYS_REFCURSOR;
BEGIN
    OPEN userTask_cursor FOR
    SELECT * FROM "UserTaskView"
    WHERE "taskID" = p_taskID;

    RETURN userTask_cursor;
END ReadUserTaskByID;

-- Function to read all clientTasks
CREATE OR REPLACE FUNCTION ReadAllUserTasks
RETURN SYS_REFCURSOR AS
    userTask_cursor SYS_REFCURSOR;
BEGIN
    OPEN userTask_cursor FOR
    SELECT * FROM "UserTaskView";

    RETURN userTask_cursor;
END ReadAllUserTasks;

-- Function to read all pending clientTasks
CREATE OR REPLACE FUNCTION ReadAllPendingUserTasks
RETURN SYS_REFCURSOR AS
    userTask_cursor SYS_REFCURSOR;
BEGIN
    OPEN userTask_cursor FOR
    SELECT * FROM "UserTaskView"
    WHERE "status" = 'pending';

    RETURN userTask_cursor;
END ReadAllPendingUserTasks;

-- Procedure to create a new clientTask
CREATE OR REPLACE PROCEDURE CreateUserTask (
    p_userID INT,
    p_action_type VARCHAR2,
    p_user_type VARCHAR2,
    p_status VARCHAR2 := 'pending'
) AS
    v_taskID INT;
BEGIN
    -- Insert into Task table
    INSERT INTO "Task" ("status", "action_type")
    VALUES (p_status, p_action_type)
    RETURNING "ID" INTO v_taskID;

    -- Insert into ClientTask table
    INSERT INTO "UserTask" ("taskID", "userID", "user_type")
    VALUES (v_taskID, p_userID, p_user_type);

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('ClientTask created successfully with task ID: ' || v_taskID);
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END CreateUserTask;

-- Procedure to update a clientTask
CREATE OR REPLACE PROCEDURE UpdateUserTask (
    p_taskID INT,
    p_status VARCHAR2
) AS
BEGIN
    UPDATE "Task"
    SET
        "status" = NVL(p_status, "status")
    WHERE "ID" = p_taskID;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('ClientTask updated successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END UpdateUserTask;

-- Procedure to delete a clientTask
CREATE OR REPLACE PROCEDURE DeleteUserTask (
    p_taskID INT
) AS
BEGIN
    DELETE FROM "Task"
    WHERE "ID" = p_taskID;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('ClientTask deleted successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END;

----------------------------------------------
--         ACCOUNT TASK MANAGEMENT          --
----------------------------------------------

-- View for AccountTask data
CREATE OR REPLACE VIEW "AccountTaskView" AS
SELECT
    at."taskID",
    at."bank_accountID",
    t."status",
    t."action_type"
FROM "AccountTask" at
INNER JOIN "Task" t ON at."taskID" = t."ID";

-- Function to read a AccountTask by ID
CREATE OR REPLACE FUNCTION ReadAccountTaskByID (
    p_taskID INT
) RETURN SYS_REFCURSOR AS
    accountTask_cursor SYS_REFCURSOR;
BEGIN
    OPEN accountTask_cursor FOR
    SELECT * FROM "AccountTaskView"
    WHERE "taskID" = p_taskID;

    RETURN accountTask_cursor;
END ReadAccountTaskByID;

-- Function to read all AccountTasks
CREATE OR REPLACE FUNCTION ReadAllAccountTasks
RETURN SYS_REFCURSOR AS
    accountTask_cursor SYS_REFCURSOR;
BEGIN
    OPEN accountTask_cursor FOR
    SELECT * FROM "AccountTaskView";

    RETURN accountTask_cursor;
END ReadAllAccountTasks;

-- Function to read all pending AccountTasks 
CREATE OR REPLACE FUNCTION ReadAllPendingAccountTasks
RETURN SYS_REFCURSOR AS
    accountTask_cursor SYS_REFCURSOR;
BEGIN
    OPEN accountTask_cursor FOR
    SELECT * FROM "AccountTaskView"
    WHERE "status" = 'pending';

    RETURN accountTask_cursor;
END ReadAllPendingAccountTasks;

-- Procedure to create a new AccountTask
CREATE OR REPLACE PROCEDURE CreateAccountTask (
    p_bank_accountID INT,
    p_action_type VARCHAR2,
    p_status VARCHAR2 := 'pending'
) AS
    v_taskID INT;
BEGIN
    -- Insert into Task table
    INSERT INTO "Task" ("status", "action_type")
    VALUES (p_status, p_action_type)
    RETURNING "ID" INTO v_taskID;

    -- Insert into AccountTask table
    INSERT INTO "AccountTask" ("taskID", "bank_accountID")
    VALUES (v_taskID, p_bank_accountID);

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('AccountTask created successfully with task ID: ' || v_taskID);
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END CreateAccountTask;

-- Procedure to update a AccountTask
CREATE OR REPLACE PROCEDURE UpdateAccountTask (
    p_taskID INT,
    p_status VARCHAR2
) AS
BEGIN
    UPDATE "Task"
    SET
        "status" = NVL(p_status, "status")
    WHERE "ID" = p_taskID;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('AccountTask updated successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END UpdateAccountTask;
----------------------------------------------
--              USER MANAGEMENT             --
----------------------------------------------

-- View for all active users
CREATE OR REPLACE VIEW "ActiveUserView" AS
SELECT u.*
FROM "User" u
INNER JOIN "UserTask" ut ON u."ID" = ut."userID"
INNER JOIN "Task" t ON ut."taskID" = t."ID"
WHERE t."status" <> 'pending'
  AND t."status" <> 'in_progress'
  AND t."status" <> 'rejected';

-- Function to read user by email
CREATE OR REPLACE FUNCTION ReadUserByEmail (
    p_email VARCHAR2
) RETURN SYS_REFCURSOR AS
    user_cursor SYS_REFCURSOR;
BEGIN
    OPEN user_cursor FOR
    SELECT * FROM "ActiveUserView"
    WHERE "email" = p_email;

    RETURN user_cursor;
END ReadUserByEmail;

----------------------------------------------
--              CLIENT MANAGEMENT           --
----------------------------------------------

-- Create views for Client tables
CREATE OR REPLACE VIEW "ClientView" AS
SELECT c."userID" AS clientID, u."firstname", u."lastname", u."nip", u."address", u."telephone", u."email"
FROM "ActiveUserView" u
INNER JOIN "Client" c ON u."ID" = c."userID";

-- Function to read a client by ID
CREATE OR REPLACE FUNCTION ReadClientByID (
    p_user_id INT
) RETURN SYS_REFCURSOR AS
    client_cursor SYS_REFCURSOR;
BEGIN
    OPEN client_cursor FOR
    SELECT * FROM "ClientView"
    WHERE clientID = p_user_id;

    RETURN client_cursor;
END ReadClientByID;

-- Function to read all clients
CREATE OR REPLACE FUNCTION ReadAllClients 
RETURN SYS_REFCURSOR AS
    client_cursor SYS_REFCURSOR;
BEGIN
    OPEN client_cursor FOR
    SELECT * FROM "ClientView";

    RETURN client_cursor;
END ReadAllClients;

-- Function to create a new client
CREATE OR REPLACE PROCEDURE CreateClient (
    p_firstname VARCHAR2,
    p_lastname VARCHAR2,
    p_nip VARCHAR2,
    p_address VARCHAR2,
    p_telephone VARCHAR2,
    p_email VARCHAR2
) AS
    v_user_id INT;
BEGIN
    -- Insert into User table
    INSERT INTO "User" ("firstname", "lastname", "nip", "address", "telephone", "email")
    VALUES (p_firstname, p_lastname, p_nip, p_address, p_telephone, p_email)
    RETURNING "ID" INTO v_user_id;

    -- Insert into Client table
    INSERT INTO "Client" ("userID")
    VALUES (v_user_id);

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Client created successfully with User ID: ' || v_user_id);
EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        DBMS_OUTPUT.PUT_LINE('Error: Email already exists.');
        ROLLBACK;
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END CreateClient;



-- Procedure to update a client
CREATE OR REPLACE PROCEDURE UpdateClient (
    p_client_id INT,
    p_firstname VARCHAR2 := NULL,
    p_lastname VARCHAR2 := NULL,
    p_nip VARCHAR2 := NULL,
    p_address VARCHAR2 := NULL,
    p_telephone VARCHAR2 := NULL,
    p_email VARCHAR2 := NULL
) AS
BEGIN
    UPDATE "User"
    SET
        "firstname" = NVL(p_firstname, "firstname"),
        "lastname" = NVL(p_lastname, "lastname"),
        "nip" = NVL(p_nip, "nip"),
        "address" = NVL(p_address, "address"),
        "telephone" = NVL(p_telephone, "telephone"),
        "email" = NVL(p_email, "email")
    WHERE "ID" = p_client_id;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Client updated successfully.');
EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        DBMS_OUTPUT.PUT_LINE('Error: Email already exists.');
        ROLLBACK;
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END UpdateClient;

-- Procedure to delete a client
CREATE OR REPLACE PROCEDURE DeleteClient (
    p_user_id INT
) AS
BEGIN
    DELETE FROM "User"
    WHERE "ID" = p_user_id;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Client deleted successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END DeleteClient;
----------------------------------------------
--              MANAGER MANAGEMENT          --
----------------------------------------------

-- View for Manager data
CREATE OR REPLACE VIEW "ManagerView" AS
SELECT m."userID" AS managerID, u.firstname, u.lastname, u.nip, u.address, u.telephone, u.email, m.role
FROM "ActiveUserView" u
INNER JOIN "Manager" m ON u."ID" = m."userID";

-- Function to read a manager by ID
CREATE OR REPLACE FUNCTION ReadManagerByID (
    p_user_id INT
) RETURN SYS_REFCURSOR AS
    manager_cursor SYS_REFCURSOR;
BEGIN
    OPEN manager_cursor FOR
    SELECT * FROM "ManagerView"
    WHERE "userID" = p_user_id;

    RETURN manager_cursor;
END ReadManagerByID;

-- Function to read all managers
CREATE OR REPLACE FUNCTION ReadAllManagers
RETURN SYS_REFCURSOR AS
    manager_cursor SYS_REFCURSOR;
BEGIN
    OPEN manager_cursor FOR
    SELECT * FROM "ManagerView";

    RETURN manager_cursor;
END ReadAllManagers;

-- Procedure to create a new manager
CREATE OR REPLACE PROCEDURE CreateManager (
    p_firstname VARCHAR2,
    p_lastname VARCHAR2,
    p_nip VARCHAR2,
    p_address VARCHAR2,
    p_telephone VARCHAR2,
    p_email VARCHAR2,
    p_role VARCHAR2
) AS
    v_user_id INT;
BEGIN
    -- Insert into User table
    INSERT INTO "User" (firstname, lastname, nip, address, telephone, email)
    VALUES (p_firstname, p_lastname, p_nip, p_address, p_telephone, p_email)
    RETURNING "ID" INTO v_user_id;

    -- Insert into Manager table
    INSERT INTO "Manager" ("userID", role)
    VALUES (v_user_id, p_role);

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Manager created successfully with User ID: ' || v_user_id);
EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        DBMS_OUTPUT.PUT_LINE('Error: Email already exists.');
        ROLLBACK;
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END CreateManager;

-- Procedure to update a manager
CREATE OR REPLACE PROCEDURE UpdateManager (
    p_user_id INT,
    p_firstname VARCHAR2 := NULL,
    p_lastname VARCHAR2 := NULL,
    p_nip VARCHAR2 := NULL,
    p_address VARCHAR2 := NULL,
    p_telephone VARCHAR2 := NULL,
    p_email VARCHAR2 := NULL,
    p_role VARCHAR2 := NULL
) AS
BEGIN
    UPDATE "User"
    SET
        firstname = NVL(p_firstname, firstname),
        lastname = NVL(p_lastname, lastname),
        nip = NVL(p_nip, nip),
        address = NVL(p_address, address),
        telephone = NVL(p_telephone, telephone),
        email = NVL(p_email, email)
    WHERE "ID" = p_user_id;

    UPDATE "Manager"
    SET
        role = NVL(p_role, role)
    WHERE "userID" = p_user_id;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Manager updated successfully.');
EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        DBMS_OUTPUT.PUT_LINE('Error: Email already exists.');
        ROLLBACK;
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END UpdateManager;

-- Procedure to delete a manager
CREATE OR REPLACE PROCEDURE DeleteManager (
    p_user_id INT
) AS
BEGIN
    DELETE FROM "User"
    WHERE "ID" = p_user_id;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Manager deleted successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END DeleteManager;
----------------------------------------------
--         BANK ACCOUNT MANAGEMENT          --
----------------------------------------------

-- View for active bank accounts
CREATE OR REPLACE VIEW "ActiveBankAccountView" AS
SELECT
    ba."ID" AS bank_accountID,
    ba."userID",
    ba."balance",
    ba."creation_date"
FROM "BankAccount" ba
INNER JOIN "AccountTaskView" at ON ba."ID" = at."bank_accountID"
WHERE at."status" NOT IN ('pending', 'in progress', 'rejected');

----------------------------------------------
--       CHECKING ACCOUNT MANAGEMENT        --
----------------------------------------------

-- View for CheckingAccount data
CREATE OR REPLACE VIEW "CheckingAccountView" AS
SELECT
    ba."ID" AS checking_accountID,
    ba."userID",
    ba."balance",
    ba."creation_date",
    ca."transaction_fee"
FROM "ActiveBankAccountView" ba
INNER JOIN "CheckingAccount" ca ON ba."ID" = ca."bank_accountID";

-- Function to read a checking account by ID
CREATE OR REPLACE FUNCTION ReadCheckingAccountByID (
    p_bank_accountID INT
) RETURN SYS_REFCURSOR AS
    checking_account_cursor SYS_REFCURSOR;
BEGIN
    OPEN checking_account_cursor FOR
    SELECT * FROM "CheckingAccountView"
    WHERE bank_accountID = p_bank_accountID;

    RETURN checking_account_cursor;
END ReadCheckingAccountByID;

-- Function to read all checking accounts
CREATE OR REPLACE FUNCTION ReadAllCheckingAccounts
RETURN SYS_REFCURSOR AS
    checking_account_cursor SYS_REFCURSOR;
BEGIN
    OPEN checking_account_cursor FOR
    SELECT * FROM "CheckingAccountView";

    RETURN checking_account_cursor;
END ReadAllCheckingAccounts;

-- Procedure to create a new checking account
CREATE OR REPLACE PROCEDURE CreateCheckingAccount (
    p_userID INT,
    p_transaction_fee DECIMAL,
    p_balance DECIMAL := 0.00,
    p_creation_date DATE := SYSDATE
) AS
    v_bank_accountID INT;
BEGIN
    -- Insert into BankAccount table
    INSERT INTO "BankAccount" ("userID", "balance", "creation_date")
    VALUES (p_userID, p_balance, p_creation_date)
    RETURNING "ID" INTO v_bank_accountID;

    -- Insert into CheckingAccount table
    INSERT INTO "CheckingAccount" ("bank_accountID", "transaction_fee")
    VALUES (v_bank_accountID, p_transaction_fee);

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Checking Account created successfully with Bank Account ID: ' || v_bank_accountID);
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END CreateCheckingAccount;

-- Procedure to update a checking account
CREATE OR REPLACE PROCEDURE UpdateCheckingAccount (
    p_bank_accountID INT,
    p_balance DECIMAL := NULL,
    p_creation_date DATE := NULL,
    p_transaction_fee DECIMAL := NULL
) AS
BEGIN
    UPDATE "BankAccount"
    SET
        "balance" = NVL(p_balance, "balance"),
        "creation_date" = NVL(p_creation_date, "creation_date")
    WHERE "ID" = p_bank_accountID;

    UPDATE "CheckingAccount"
    SET
        "transaction_fee" = NVL(p_transaction_fee, "transaction_fee")
    WHERE "bank_accountID" = p_bank_accountID;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Checking Account updated successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END UpdateCheckingAccount;

-- Procedure to delete a checking account
CREATE OR REPLACE PROCEDURE DeleteCheckingAccount (
    p_bank_accountID INT
) AS
BEGIN
    DELETE FROM "BankAccount"
    WHERE "ID" = p_bank_accountID;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Checking Account deleted successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END DeleteCheckingAccount;
----------------------------------------------
--         SAVING ACCOUNT MANAGEMENT        --
----------------------------------------------

-- View for SavingAccount data
CREATE OR REPLACE VIEW "SavingAccountView" AS
SELECT
    ba."ID" AS saving_accountID,
    ba."userID",
    ba."balance",
    ba."creation_date",
    sa."interest_rate"
FROM "ActiveBankAccountView" ba
INNER JOIN "SavingAccount" sa ON ba."ID" = sa."bank_accountID";

-- Function to read a saving account by ID
CREATE OR REPLACE FUNCTION ReadSavingAccountByID (
    p_bank_accountID INT
) RETURN SYS_REFCURSOR AS
    saving_account_cursor SYS_REFCURSOR;
BEGIN
    OPEN saving_account_cursor FOR
    SELECT * FROM "SavingAccountView"
    WHERE bank_accountID = p_bank_accountID;

    RETURN saving_account_cursor;
END ReadSavingAccountByID;

-- Function to read all saving accounts
CREATE OR REPLACE FUNCTION ReadAllSavingAccounts
RETURN SYS_REFCURSOR AS
    saving_account_cursor SYS_REFCURSOR;
BEGIN
    OPEN saving_account_cursor FOR
    SELECT * FROM "SavingAccountView";

    RETURN saving_account_cursor;
END ReadAllSavingAccounts;

-- Procedure to create a new saving account
CREATE OR REPLACE PROCEDURE CreateSavingAccount (
    p_userID INT,
    p_interest_rate DECIMAL,
    p_balance DECIMAL := 0.00,
    p_creation_date DATE := SYSDATE
) AS
    v_bank_accountID INT;
BEGIN
    -- Insert into BankAccount table
    INSERT INTO "BankAccount" ("userID", "balance", "creation_date")
    VALUES (p_userID, p_balance, p_creation_date)
    RETURNING "ID" INTO v_bank_accountID;

    -- Insert into SavingAccount table
    INSERT INTO "SavingAccount" ("bank_accountID", "interest_rate")
    VALUES (v_bank_accountID, p_interest_rate);

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Saving Account created successfully with Bank Account ID: ' || v_bank_accountID);
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END CreateSavingAccount;

-- Procedure to update a saving account
CREATE OR REPLACE PROCEDURE UpdateSavingAccount (
    p_bank_accountID INT,
    p_balance DECIMAL := NULL,
    p_creation_date DATE := NULL,
    p_interest_rate DECIMAL := NULL
) AS
BEGIN
    UPDATE "BankAccount"
    SET
        "balance" = NVL(p_balance, "balance"),
        "creation_date" = NVL(p_creation_date, "creation_date")
    WHERE "ID" = p_bank_accountID;

    UPDATE "SavingAccount"
    SET
        "interest_rate" = NVL(p_interest_rate, "interest_rate")
    WHERE "bank_accountID" = p_bank_accountID;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Saving Account updated successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END UpdateSavingAccount;

-- Procedure to delete a saving account
CREATE OR REPLACE PROCEDURE DeleteSavingAccount (
    p_bank_accountID INT
) AS
BEGIN
    DELETE FROM "BankAccount"
    WHERE "ID" = p_bank_accountID;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Saving Account deleted successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END DeleteSavingAccount;
----------------------------------------------
--       CURRENCY ACCOUNT MANAGEMENT        --
----------------------------------------------

-- View for CurrencyAccount data
CREATE OR REPLACE VIEW "CurrencyAccountView" AS
SELECT
    ba."ID" AS currency_accountID,
    ba."userID",
    ba."balance",
    ba."creation_date",
    ca."currency",
    ca."exchange_rate"
FROM "ActiveBankAccountView" ba
INNER JOIN "CurrencyAccount" ca ON ba."ID" = ca."bank_accountID";

-- Function to read a currency account by ID
CREATE OR REPLACE FUNCTION ReadCurrencyAccountByID (
    p_bank_accountID INT
) RETURN SYS_REFCURSOR AS
    currency_account_cursor SYS_REFCURSOR;
BEGIN
    OPEN currency_account_cursor FOR
    SELECT * FROM "CurrencyAccountView"
    WHERE currency_accountID = p_bank_accountID;

    RETURN currency_account_cursor;
END ReadCurrencyAccountByID;

-- Function to read all currency accounts
CREATE OR REPLACE FUNCTION ReadAllCurrencyAccounts
RETURN SYS_REFCURSOR AS
    currency_account_cursor SYS_REFCURSOR;
BEGIN
    OPEN currency_account_cursor FOR
    SELECT * FROM "CurrencyAccountView";

    RETURN currency_account_cursor;
END ReadAllCurrencyAccounts;

-- Procedure to create a new currency account
CREATE OR REPLACE PROCEDURE CreateCurrencyAccount (
    p_userID INT,
    p_currency VARCHAR2,
    p_exchange_rate DECIMAL,
    p_balance DECIMAL := 0.00,
    p_creation_date DATE := SYSDATE
) AS
    v_bank_accountID INT;
BEGIN
    -- Insert into BankAccount table
    INSERT INTO "BankAccount" ("userID", "balance", "creation_date")
    VALUES (p_userID, p_balance, p_creation_date)
    RETURNING "ID" INTO v_bank_accountID;

    -- Insert into CurrencyAccount table
    INSERT INTO "CurrencyAccount" ("bank_accountID", "currency", "exchange_rate")
    VALUES (v_bank_accountID, p_currency, p_exchange_rate);

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Currency Account created successfully with Bank Account ID: ' || v_bank_accountID);
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END CreateCurrencyAccount;

-- Procedure to update a currency account
CREATE OR REPLACE PROCEDURE UpdateCurrencyAccount (
    p_bank_accountID INT,
    p_balance DECIMAL := NULL,
    p_creation_date DATE := NULL,
    p_currency VARCHAR2 := NULL,
    p_exchange_rate DECIMAL := NULL
) AS
BEGIN
    UPDATE "BankAccount"
    SET
        "balance" = NVL(p_balance, "balance"),
        "creation_date" = NVL(p_creation_date, "creation_date")
    WHERE "ID" = p_bank_accountID;

    UPDATE "CurrencyAccount"
    SET
        "currency" = NVL(p_currency, "currency"),
        "exchange_rate" = NVL(p_exchange_rate, "exchange_rate")
    WHERE "bank_accountID" = p_bank_accountID;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Currency Account updated successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END UpdateCurrencyAccount;

-- Procedure to delete a currency account
CREATE OR REPLACE PROCEDURE DeleteCurrencyAccount (
    p_bank_accountID INT
) AS
BEGIN
    DELETE FROM "BankAccount"
    WHERE "ID" = p_bank_accountID;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Currency Account deleted successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END DeleteCurrencyAccount;
----------------------------------------------
--         CREDIT ACCOUNT MANAGEMENT        --
----------------------------------------------

-- View for CreditAccount data
CREATE OR REPLACE VIEW "CreditAccountView" AS
SELECT
    ba."ID" AS credit_accountID,
    ba."userID",
    ba."balance",
    ba."creation_date",
    ca."interest_rate"
FROM "ActiveBankAccountView" ba
INNER JOIN "CreditAccount" ca ON ba."ID" = ca."bank_accountID";

-- Function to read a credit account by ID
CREATE OR REPLACE FUNCTION ReadCreditAccountByID (
    p_bank_accountID INT
) RETURN SYS_REFCURSOR AS
    credit_account_cursor SYS_REFCURSOR;
BEGIN
    OPEN credit_account_cursor FOR
    SELECT * FROM "CreditAccountView"
    WHERE credit_accountID = p_bank_accountID;

    RETURN credit_account_cursor;
END ReadCreditAccountByID;

-- Function to read all credit accounts
CREATE OR REPLACE FUNCTION ReadAllCreditAccounts
RETURN SYS_REFCURSOR AS
    credit_account_cursor SYS_REFCURSOR;
BEGIN
    OPEN credit_account_cursor FOR
    SELECT * FROM "CreditAccountView";

    RETURN credit_account_cursor;
END ReadAllCreditAccounts;

-- Procedure to create a new credit account
CREATE OR REPLACE PROCEDURE CreateCreditAccount (
    p_userID INT,
    p_interest_rate DECIMAL,
    p_balance DECIMAL := 0.00,
    p_creation_date DATE := SYSDATE
) AS
    v_bank_accountID INT;
BEGIN
    -- Insert into BankAccount table
    INSERT INTO "BankAccount" ("userID", "balance", "creation_date")
    VALUES (p_userID, p_balance, p_creation_date)
    RETURNING "ID" INTO v_bank_accountID;

    -- Insert into CreditAccount table
    INSERT INTO "CreditAccount" ("bank_accountID", "interest_rate")
    VALUES (v_bank_accountID, p_interest_rate);

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Credit Account created successfully with Bank Account ID: ' || v_bank_accountID);
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END CreateCreditAccount;

-- Procedure to update a credit account
CREATE OR REPLACE PROCEDURE UpdateCreditAccount (
    p_bank_accountID INT,
    p_balance DECIMAL := NULL,
    p_creation_date DATE := NULL,
    p_interest_rate DECIMAL := NULL
) AS
BEGIN
    UPDATE "BankAccount"
    SET
        "balance" = NVL(p_balance, "balance"),
        "creation_date" = NVL(p_creation_date, "creation_date")
    WHERE "ID" = p_bank_accountID;

    UPDATE "CreditAccount"
    SET
        "interest_rate" = NVL(p_interest_rate, "interest_rate")
    WHERE "bank_accountID" = p_bank_accountID;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Credit Account updated successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END UpdateCreditAccount;

-- Procedure to delete a credit account
CREATE OR REPLACE PROCEDURE DeleteCreditAccount (
    p_bank_accountID INT
) AS
BEGIN
    DELETE FROM "BankAccount"
    WHERE "ID" = p_bank_accountID;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Credit Account deleted successfully.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END DeleteCreditAccount;
----------------------------------------------
--      TRANSACTION RECORD MANAGEMENT       --
----------------------------------------------

-- Function to read a transaction record for a specific bank account
CREATE OR REPLACE FUNCTION ReadTransactionRecordFor(
    bank_accountID INT
) return SYS_REFCURSOR AS
    transaction_cursor SYS_REFCURSOR;
BEGIN
    OPEN transaction_cursor FOR
    SELECT * FROM "TransactionRecord"
    WHERE bank_accountID = bank_accountID
    ORDER BY historicID ASC;

    RETURN transaction_cursor;
END ReadTransactionRecordForm;

-- Function to read all transaction records
CREATE OR REPLACE FUNCTION ReadAllTransactionRecords
RETURN SYS_REFCURSOR AS
        transaction_cursor SYS_REFCURSOR;
BEGIN
        OPEN transaction_cursor FOR
        SELECT * FROM "TransactionRecord"
        ORDER BY historicID ASC;

        RETURN transaction_cursor;
END ReadAllTransactionRecords;

-- Procedure to create a new transaction record
CREATE OR REPLACE PROCEDURE CreateTransactionRecord (
        p_bank_accountID INT,
        p_type VARCHAR2,
        p_operation DECIMAL,
        p_date DATE := SYSDATE
) AS
BEGIN
        -- Insert into TransactionRecord table
        INSERT INTO "TransactionRecord" (bank_accountID, type, operation, date)
        VALUES (p_bank_accountID, p_type, p_operation, p_date);

        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Transaction Record created successfully with Historic ID: ' || v_historicID);
EXCEPTION
        WHEN OTHERS THEN
                DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
                ROLLBACK;
END CreateTransactionRecord;

----------------------------------------------
--         NOTIFICATION MANAGEMENT          --
----------------------------------------------

-- Procedure to read all notifications for a client
CREATE OR REPLACE FUNCTION ReadAllUnreadNotificationsForClient (
        p_clientID INT
) RETURN SYS_REFCURSOR AS
        notification_cursor SYS_REFCURSOR;
BEGIN
        OPEN notification_cursor FOR
        SELECT * FROM "Notification"
        WHERE clientID = p_clientID
        AND status = 'sent'
        ORDER BY ID ASC;

        RETURN notification_cursor;
END ReadAllNotificationsForClient;

-- Function to read all notifications for a bank account that are not archived
CREATE OR REPLACE FUNCTION ReadAllNotificationsForBankAccount (
        p_bank_accountID INT
) RETURN SYS_REFCURSOR AS
        notification_cursor SYS_REFCURSOR;
BEGIN
        OPEN notification_cursor FOR
        SELECT * FROM "Notification"
        WHERE bank_accountID = p_bank_accountID
        AND status != 'archived'
        ORDER BY ID ASC;

        RETURN notification_cursor;
END ReadAllNotificationsForBankAccount;

-- Procedure to create a new notification
CREATE OR REPLACE PROCEDURE CreateNotification (
        p_bank_accountID INT,
        p_clientID INT,
        p_message VARCHAR2,
        p_status VARCHAR2 := 'sent'
) AS 
BEGIN
        -- Insert into Notification table
        INSERT INTO "Notification" (bank_accountID, clientID, message, status)
        VALUES (p_bank_accountID, p_clientID, p_message, p_status);

        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Notification created successfully with ID: ' || v_ID);
EXCEPTION
        WHEN OTHERS THEN
                DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
                ROLLBACK;
END CreateNotification;

-- Procedure to update a notification
CREATE OR REPLACE PROCEDURE UpdateNotification (
        p_ID INT,
        p_status VARCHAR2
) AS
BEGIN
        UPDATE "Notification"
        SET status = p_status
        WHERE ID = p_ID;

        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Notification updated successfully.');
EXCEPTION
        WHEN OTHERS THEN
                DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
                ROLLBACK;
END UpdateNotification;

-- Procedure to read a notification
CREATE OR REPLACE PROCEDURE SetNotificationToRead (
        p_ID INT
) AS
BEGIN
        EXEC UpdateNotification(p_ID, 'read');
        DBMS_OUTPUT.PUT_LINE('Notification read successfully.');
EXCEPTION
        WHEN OTHERS THEN
                DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
                ROLLBACK;
END SetNotificationToRead;

-- Procedure to archive a notification
CREATE OR REPLACE PROCEDURE ArchiveNotification (
        p_ID INT
) AS
BEGIN
        EXEC UpdateNotification(p_ID, 'archived');
        DBMS_OUTPUT.PUT_LINE('Notification archived successfully.');    
EXCEPTION
        WHEN OTHERS THEN
                DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
                ROLLBACK;
END ArchiveNotification;

/
--------------------------------------------------------
--  Constraints for Table AccountTask
--------------------------------------------------------

  ALTER TABLE "C##JAVA_BANK"."AccountTask" MODIFY ("bank_accountID" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."AccountTask" ADD PRIMARY KEY ("taskID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Constraints for Table BankAccount
--------------------------------------------------------

  ALTER TABLE "C##JAVA_BANK"."BankAccount" MODIFY ("userID" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."BankAccount" MODIFY ("balance" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."BankAccount" MODIFY ("creation_date" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."BankAccount" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Constraints for Table CheckingAccount
--------------------------------------------------------

  ALTER TABLE "C##JAVA_BANK"."CheckingAccount" MODIFY ("transaction_fee" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."CheckingAccount" ADD PRIMARY KEY ("bank_accountID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Constraints for Table Client
--------------------------------------------------------

  ALTER TABLE "C##JAVA_BANK"."Client" ADD PRIMARY KEY ("userID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Constraints for Table CreditAccount
--------------------------------------------------------

  ALTER TABLE "C##JAVA_BANK"."CreditAccount" MODIFY ("interest_rate" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."CreditAccount" ADD CONSTRAINT "POSITIVE_RATE_CHK" CHECK ("interest_rate" >= 0) ENABLE;
  ALTER TABLE "C##JAVA_BANK"."CreditAccount" ADD PRIMARY KEY ("bank_accountID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Constraints for Table CurrencyAccount
--------------------------------------------------------

  ALTER TABLE "C##JAVA_BANK"."CurrencyAccount" MODIFY ("currency" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."CurrencyAccount" MODIFY ("exchange_rate" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."CurrencyAccount" ADD CONSTRAINT "CURRENCY_CHECK" CHECK ("currency" IN ('USD', 'EUR', 'GBP', 'JPY', 'CHF', 'AUD', 'CAD', 'NZD')) ENABLE;
  ALTER TABLE "C##JAVA_BANK"."CurrencyAccount" ADD PRIMARY KEY ("bank_accountID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Constraints for Table Manager
--------------------------------------------------------

  ALTER TABLE "C##JAVA_BANK"."Manager" MODIFY ("role" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."Manager" ADD PRIMARY KEY ("userID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Constraints for Table Notification
--------------------------------------------------------

  ALTER TABLE "C##JAVA_BANK"."Notification" MODIFY ("bank_accountID" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."Notification" MODIFY ("clientID" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."Notification" MODIFY ("status" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."Notification" MODIFY ("message" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."Notification" ADD CONSTRAINT "NOTIFICATION_STATUS_CHECK" CHECK ("status" IN ('sent', 'read', 'archived')) ENABLE;
  ALTER TABLE "C##JAVA_BANK"."Notification" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Constraints for Table SavingAccount
--------------------------------------------------------

  ALTER TABLE "C##JAVA_BANK"."SavingAccount" MODIFY ("interest_rate" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."SavingAccount" ADD PRIMARY KEY ("bank_accountID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Constraints for Table Task
--------------------------------------------------------

  ALTER TABLE "C##JAVA_BANK"."Task" MODIFY ("status" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."Task" MODIFY ("action_type" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."Task" ADD CONSTRAINT "TASK_STATUS_CHECK" CHECK ("status" IN ('pending', 'in_progress', 'accepted', 'rejected', 'completed')) ENABLE;
  ALTER TABLE "C##JAVA_BANK"."Task" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
  ALTER TABLE "C##JAVA_BANK"."Task" ADD CONSTRAINT "TASK_ACTION_TYPE_CHECK" CHECK ("action_type" IN ('creation', 'deletion')) ENABLE;
--------------------------------------------------------
--  Constraints for Table TransactionRecord
--------------------------------------------------------

  ALTER TABLE "C##JAVA_BANK"."TransactionRecord" MODIFY ("balance" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."TransactionRecord" MODIFY ("historicID" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."TransactionRecord" MODIFY ("bank_accountID" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."TransactionRecord" MODIFY ("type" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."TransactionRecord" MODIFY ("operation" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."TransactionRecord" MODIFY ("date" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."TransactionRecord" ADD PRIMARY KEY ("bank_accountID", "historicID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Constraints for Table User
--------------------------------------------------------

  ALTER TABLE "C##JAVA_BANK"."User" MODIFY ("firstname" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."User" MODIFY ("lastname" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."User" MODIFY ("nip" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."User" MODIFY ("address" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."User" MODIFY ("telephone" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."User" MODIFY ("email" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."User" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
  ALTER TABLE "C##JAVA_BANK"."User" ADD UNIQUE ("email")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Constraints for Table UserTask
--------------------------------------------------------

  ALTER TABLE "C##JAVA_BANK"."UserTask" MODIFY ("userID" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."UserTask" MODIFY ("user_type" NOT NULL ENABLE);
  ALTER TABLE "C##JAVA_BANK"."UserTask" ADD CONSTRAINT "USER_TYPE_CHECK" CHECK ("user_type" IN ('client', 'manager')) ENABLE;
  ALTER TABLE "C##JAVA_BANK"."UserTask" ADD PRIMARY KEY ("taskID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table AccountTask
--------------------------------------------------------

  ALTER TABLE "C##JAVA_BANK"."AccountTask" ADD FOREIGN KEY ("bank_accountID")
	  REFERENCES "C##JAVA_BANK"."BankAccount" ("ID") ON DELETE CASCADE ENABLE;
  ALTER TABLE "C##JAVA_BANK"."AccountTask" ADD FOREIGN KEY ("taskID")
	  REFERENCES "C##JAVA_BANK"."Task" ("ID") ON DELETE CASCADE ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table BankAccount
--------------------------------------------------------

  ALTER TABLE "C##JAVA_BANK"."BankAccount" ADD FOREIGN KEY ("userID")
	  REFERENCES "C##JAVA_BANK"."User" ("ID") ON DELETE CASCADE ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table CheckingAccount
--------------------------------------------------------

  ALTER TABLE "C##JAVA_BANK"."CheckingAccount" ADD FOREIGN KEY ("bank_accountID")
	  REFERENCES "C##JAVA_BANK"."BankAccount" ("ID") ON DELETE CASCADE ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table Client
--------------------------------------------------------

  ALTER TABLE "C##JAVA_BANK"."Client" ADD FOREIGN KEY ("userID")
	  REFERENCES "C##JAVA_BANK"."User" ("ID") ON DELETE CASCADE ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table CreditAccount
--------------------------------------------------------

  ALTER TABLE "C##JAVA_BANK"."CreditAccount" ADD FOREIGN KEY ("bank_accountID")
	  REFERENCES "C##JAVA_BANK"."BankAccount" ("ID") ON DELETE CASCADE ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table CurrencyAccount
--------------------------------------------------------

  ALTER TABLE "C##JAVA_BANK"."CurrencyAccount" ADD FOREIGN KEY ("bank_accountID")
	  REFERENCES "C##JAVA_BANK"."BankAccount" ("ID") ON DELETE CASCADE ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table Manager
--------------------------------------------------------

  ALTER TABLE "C##JAVA_BANK"."Manager" ADD FOREIGN KEY ("userID")
	  REFERENCES "C##JAVA_BANK"."User" ("ID") ON DELETE CASCADE ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table Notification
--------------------------------------------------------

  ALTER TABLE "C##JAVA_BANK"."Notification" ADD FOREIGN KEY ("clientID")
	  REFERENCES "C##JAVA_BANK"."Client" ("userID") ON DELETE CASCADE ENABLE;
  ALTER TABLE "C##JAVA_BANK"."Notification" ADD FOREIGN KEY ("bank_accountID")
	  REFERENCES "C##JAVA_BANK"."BankAccount" ("ID") ON DELETE CASCADE ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table SavingAccount
--------------------------------------------------------

  ALTER TABLE "C##JAVA_BANK"."SavingAccount" ADD FOREIGN KEY ("bank_accountID")
	  REFERENCES "C##JAVA_BANK"."BankAccount" ("ID") ON DELETE CASCADE ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table TransactionRecord
--------------------------------------------------------

  ALTER TABLE "C##JAVA_BANK"."TransactionRecord" ADD FOREIGN KEY ("bank_accountID")
	  REFERENCES "C##JAVA_BANK"."BankAccount" ("ID") ON DELETE CASCADE ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table UserTask
--------------------------------------------------------

  ALTER TABLE "C##JAVA_BANK"."UserTask" ADD FOREIGN KEY ("userID")
	  REFERENCES "C##JAVA_BANK"."User" ("ID") ON DELETE CASCADE ENABLE;
  ALTER TABLE "C##JAVA_BANK"."UserTask" ADD FOREIGN KEY ("taskID")
	  REFERENCES "C##JAVA_BANK"."Task" ("ID") ON DELETE CASCADE ENABLE;
